# PharmaGest Pro

Application complète de gestion de pharmacie — React + Tailwind CSS + Express + Prisma + MySQL.

## Prérequis (Windows)

1. **Node.js** v18+ : https://nodejs.org/
2. **MySQL** 8.x : https://dev.mysql.com/downloads/installer/
3. **Git** (optionnel)

## Installation

### 1. Créer la base de données MySQL

Ouvrez **MySQL Workbench** ou **mysql** en ligne de commande :

```sql
CREATE DATABASE pharmagest_pro CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```

Notez votre utilisateur et mot de passe MySQL (souvent `root` / votre mot de passe).

### 2. Configurer le backend

```powershell
cd pharmagest-pro\backend
copy .env.example .env
```

Éditez `.env` et adaptez :

```
DATABASE_URL="mysql://root:VOTRE_MOT_DE_PASSE@localhost:3306/pharmagest_pro"
JWT_SECRET="une-cle-secrete-longue-et-aleatoire"
PORT=5000
FRONTEND_URL="http://localhost:5173"
```

### 3. Installer les dépendances backend

```powershell
cd pharmagest-pro\backend
npm install
```

### 4. Générer Prisma et migrer

```powershell
npx prisma generate
npx prisma migrate dev --name init
```

### 5. Charger les données de démonstration

```powershell
npx tsx prisma/seed.ts
```

### 6. Installer et lancer le frontend

Dans un **nouveau terminal** :

```powershell
cd pharmagest-pro\frontend
npm install
npm run dev
```

### 7. Lancer le backend

Dans le terminal backend :

```powershell
cd pharmagest-pro\backend
npm run dev
```

### 8. Accéder à l'application

Ouvrez : **http://localhost:5173**

## Comptes de démonstration

| Rôle        | Email                     | Mot de passe |
|-------------|---------------------------|--------------|
| Admin       | admin@pharmagest.mg       | Demo2024!    |
| Pharmacien  | pharmacien@pharmagest.mg  | Demo2024!    |
| Client      | client@demo.mg            | Demo2024!    |

## Fonctionnalités

### Espace Administrateur / Responsable
- Tableau de bord (stats, graphiques, alertes)
- Point de vente (POS) avec recherche rapide
- Gestion des médicaments (CRUD)
- Gestion du stock (entrées, alertes, péremption FEFO)
- Validation des commandes clients
- Historique des ventes + factures PDF
- Gestion des utilisateurs (Admin uniquement)
- Notifications

### Espace Client
- Catalogue et recherche de médicaments
- Panier et soumission de commande
- Suivi des commandes
- Notifications de statut

## Structure du projet

```
pharmagest-pro/
├── backend/
│   ├── prisma/
│   │   ├── schema.prisma
│   │   └── seed.ts
│   ├── src/
│   │   ├── controllers/
│   │   ├── middlewares/
│   │   ├── routes/
│   │   ├── services/
│   │   ├── utils/
│   │   └── index.ts
│   ├── package.json
│   └── .env.example
├── frontend/
│   ├── src/
│   │   ├── components/
│   │   ├── contexts/
│   │   ├── layouts/
│   │   ├── pages/
│   │   ├── services/
│   │   ├── App.tsx
│   │   └── main.tsx
│   └── package.json
└── README.md
```

## Sauvegarde MySQL

```powershell
# Sauvegarder
mysqldump -u root -p pharmagest_pro > backup_pharmagest.sql

# Restaurer
mysql -u root -p pharmagest_pro < backup_pharmagest.sql
```

## Ports

| Service  | URL                      |
|----------|--------------------------|
| Frontend | http://localhost:5173    |
| Backend  | http://localhost:5000    |
| API Health | http://localhost:5000/api/health |

## Notes importantes

- Les ventes utilisent des **transactions MySQL** pour garantir la cohérence stock + vente.
- Le stock utilise la méthode **FEFO** (First Expired, First Out).
- Les factures PDF sont générées dans le dossier `backend/invoices/`.
- Les alertes stock/péremption sont vérifiées périodiquement côté serveur.
- Ne jamais committer le fichier `.env` (déjà dans `.gitignore`).
