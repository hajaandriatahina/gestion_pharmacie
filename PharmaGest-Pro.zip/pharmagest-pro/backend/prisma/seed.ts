import { PrismaClient, Role } from '@prisma/client';
import bcrypt from 'bcryptjs';
import { Decimal } from '@prisma/client/runtime/library';

const prisma = new PrismaClient();

async function main() {
  console.log('🌱 Seeding PharmaGest Pro...');

  // Settings
  const existingSettings = await prisma.pharmacySettings.findFirst();
  if (!existingSettings) {
    await prisma.pharmacySettings.create({
      data: {
        name: 'Pharmacie PharmaGest Pro',
        address: '123 Avenue de l\'Indépendance, Antananarivo 101',
        phone: '+261 20 22 123 45',
        email: 'contact@pharmagest.mg',
        nif: '3000123456',
        stat: '12345 11 2020 0 12345',
        lowStockThreshold: 10,
        expiryAlertDays: 90,
        currency: 'MGA',
        legalMentions: 'TVA non applicable — Art. 293 B du CGI. Document généré par PharmaGest Pro.',
      },
    });
  }

  const passwordHash = await bcrypt.hash('Demo2024!', 12);

  // Users
  const admin = await prisma.user.upsert({
    where: { email: 'admin@pharmagest.mg' },
    update: {},
    create: {
      email: 'admin@pharmagest.mg',
      passwordHash,
      firstName: 'Jean',
      lastName: 'Rakoto',
      role: Role.ADMIN,
      phone: '+261 34 00 000 01',
    },
  });

  const responsable = await prisma.user.upsert({
    where: { email: 'pharmacien@pharmagest.mg' },
    update: {},
    create: {
      email: 'pharmacien@pharmagest.mg',
      passwordHash,
      firstName: 'Marie',
      lastName: 'Rasoanaivo',
      role: Role.RESPONSABLE,
      phone: '+261 34 00 000 02',
    },
  });

  const client = await prisma.user.upsert({
    where: { email: 'client@demo.mg' },
    update: {},
    create: {
      email: 'client@demo.mg',
      passwordHash,
      firstName: 'Paul',
      lastName: 'Andriamanana',
      role: Role.CLIENT,
      phone: '+261 34 00 000 03',
      clientProfile: {
        create: {
          address: 'Lot II M 45 Bis, Antananarivo',
          city: 'Antananarivo',
        },
      },
    },
  });

  // Categories
  const catAnalgesiques = await prisma.category.upsert({
    where: { name: 'Analgésiques' },
    update: {},
    create: { name: 'Analgésiques', description: 'Antidouleurs et antipyrétiques' },
  });
  const catAntibiotiques = await prisma.category.upsert({
    where: { name: 'Antibiotiques' },
    update: {},
    create: { name: 'Antibiotiques', description: 'Antibiotiques (ordonnance requise)' },
  });
  const catVitamines = await prisma.category.upsert({
    where: { name: 'Vitamines & Compléments' },
    update: {},
    create: { name: 'Vitamines & Compléments', description: 'Vitamines et compléments alimentaires' },
  });
  const catDigestif = await prisma.category.upsert({
    where: { name: 'Digestifs' },
    update: {},
    create: { name: 'Digestifs', description: 'Troubles digestifs' },
  });

  // Médicaments
  const meds = [
    {
      code: 'PARA500',
      name: 'Paracétamol 500mg',
      activeIngredient: 'Paracétamol',
      form: 'Comprimé',
      dosage: '500 mg',
      laboratory: 'Sanofi',
      purchasePrice: 50,
      salePrice: 100,
      minStock: 50,
      categoryId: catAnalgesiques.id,
      requiresPrescription: false,
    },
    {
      code: 'IBUP400',
      name: 'Ibuprofène 400mg',
      activeIngredient: 'Ibuprofène',
      form: 'Comprimé',
      dosage: '400 mg',
      laboratory: 'Pfizer',
      purchasePrice: 80,
      salePrice: 150,
      minStock: 30,
      categoryId: catAnalgesiques.id,
      requiresPrescription: false,
    },
    {
      code: 'AMOX500',
      name: 'Amoxicilline 500mg',
      activeIngredient: 'Amoxicilline',
      form: 'Gélule',
      dosage: '500 mg',
      laboratory: 'GSK',
      purchasePrice: 200,
      salePrice: 350,
      minStock: 20,
      categoryId: catAntibiotiques.id,
      requiresPrescription: true,
    },
    {
      code: 'VITC1000',
      name: 'Vitamine C 1000mg',
      activeIngredient: 'Acide ascorbique',
      form: 'Comprimé effervescent',
      dosage: '1000 mg',
      laboratory: 'Bayer',
      purchasePrice: 120,
      salePrice: 250,
      minStock: 40,
      categoryId: catVitamines.id,
      requiresPrescription: false,
    },
    {
      code: 'OMEP20',
      name: 'Oméprazole 20mg',
      activeIngredient: 'Oméprazole',
      form: 'Gélule',
      dosage: '20 mg',
      laboratory: 'AstraZeneca',
      purchasePrice: 150,
      salePrice: 300,
      minStock: 25,
      categoryId: catDigestif.id,
      requiresPrescription: false,
    },
    {
      code: 'DOLI1000',
      name: 'Doliprane 1000mg',
      activeIngredient: 'Paracétamol',
      form: 'Comprimé',
      dosage: '1000 mg',
      laboratory: 'Sanofi',
      purchasePrice: 80,
      salePrice: 180,
      minStock: 40,
      categoryId: catAnalgesiques.id,
      requiresPrescription: false,
    },
  ];

  const createdMeds = [];
  for (const m of meds) {
    const med = await prisma.medicine.upsert({
      where: { code: m.code },
      update: {},
      create: {
        ...m,
        purchasePrice: new Decimal(m.purchasePrice),
        salePrice: new Decimal(m.salePrice),
      },
    });
    createdMeds.push(med);
  }

  // Supplier
  const supplier = await prisma.supplier.upsert({
    where: { id: 'sup-demo-1' },
    update: {},
    create: {
      id: 'sup-demo-1',
      name: 'Pharma Distribution Madagascar',
      contactName: 'Ravo Andria',
      phone: '+261 32 00 111 22',
      email: 'contact@pharmadist.mg',
      address: 'Zone Industrielle, Antananarivo',
    },
  });

  // Lots (batches)
  const now = new Date();
  const in6months = new Date(now);
  in6months.setMonth(in6months.getMonth() + 6);
  const in3months = new Date(now);
  in3months.setMonth(in3months.getMonth() + 3);
  const in18months = new Date(now);
  in18months.setMonth(in18months.getMonth() + 18);

  for (let i = 0; i < createdMeds.length; i++) {
    const med = createdMeds[i];
    await prisma.batch.upsert({
      where: {
        medicineId_batchNumber: {
          medicineId: med.id,
          batchNumber: `LOT-2024-${String(i + 1).padStart(3, '0')}`,
        },
      },
      update: {},
      create: {
        medicineId: med.id,
        batchNumber: `LOT-2024-${String(i + 1).padStart(3, '0')}`,
        quantity: 100 + i * 20,
        initialQty: 100 + i * 20,
        expiryDate: i === 1 ? in3months : i === 2 ? in6months : in18months,
        purchasePrice: med.purchasePrice,
        supplierId: supplier.id,
      },
    });
  }

  console.log('✅ Seed terminé avec succès !');
  console.log('');
  console.log('Comptes de démonstration (mot de passe: Demo2024!) :');
  console.log('  Admin       : admin@pharmagest.mg');
  console.log('  Responsable : pharmacien@pharmagest.mg');
  console.log('  Client      : client@demo.mg');
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
