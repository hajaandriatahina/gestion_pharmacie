import PDFDocument from 'pdfkit';
import fs from 'fs';
import path from 'path';
import { prisma } from '../utils/prisma.js';
import { NotFoundError } from '../utils/errors.js';

const INVOICES_DIR = path.join(process.cwd(), 'invoices');

if (!fs.existsSync(INVOICES_DIR)) {
  fs.mkdirSync(INVOICES_DIR, { recursive: true });
}

export async function generateInvoicePDF(saleId: string): Promise<string> {
  const sale = await prisma.sale.findUnique({
    where: { id: saleId },
    include: {
      seller: { select: { firstName: true, lastName: true } },
      items: {
        include: {
          medicine: { select: { name: true, code: true, dosage: true } },
        },
      },
      invoice: true,
      payment: true,
    },
  });

  if (!sale || !sale.invoice) throw new NotFoundError('Vente ou facture introuvable');

  const settings = await prisma.pharmacySettings.findFirst();

  const fileName = `${sale.invoice.invoiceNumber}.pdf`;
  const filePath = path.join(INVOICES_DIR, fileName);

  return new Promise((resolve, reject) => {
    const doc = new PDFDocument({ margin: 50, size: 'A4' });
    const stream = fs.createWriteStream(filePath);
    doc.pipe(stream);

    // En-tête
    doc.fontSize(20).fillColor('#1e40af').text(settings?.name || 'PharmaGest Pro', { align: 'left' });
    doc.fontSize(9).fillColor('#64748b');
    if (settings?.address) doc.text(settings.address);
    if (settings?.phone) doc.text(`Tél: ${settings.phone}`);
    if (settings?.email) doc.text(settings.email);
    if (settings?.nif) doc.text(`NIF: ${settings.nif}`);
    if (settings?.stat) doc.text(`STAT: ${settings.stat}`);

    doc.moveDown();
    doc.fontSize(16).fillColor('#0f172a').text('FACTURE', { align: 'right' });
    doc.fontSize(10).fillColor('#334155');
    doc.text(`N° ${sale.invoice.invoiceNumber}`, { align: 'right' });
    doc.text(`Date: ${sale.createdAt.toLocaleString('fr-FR')}`, { align: 'right' });
    doc.text(`Vendeur: ${sale.seller.firstName} ${sale.seller.lastName}`, { align: 'right' });

    doc.moveDown(1.5);

    // Ligne de séparation
    doc.strokeColor('#e2e8f0').lineWidth(1).moveTo(50, doc.y).lineTo(545, doc.y).stroke();
    doc.moveDown();

    // Tableau
    const tableTop = doc.y;
    doc.fontSize(9).fillColor('#1e40af').font('Helvetica-Bold');
    doc.text('Médicament', 50, tableTop);
    doc.text('Qté', 300, tableTop);
    doc.text('P.U.', 350, tableTop);
    doc.text('Total', 450, tableTop, { align: 'right' });

    doc.moveDown(0.5);
    doc.strokeColor('#e2e8f0').moveTo(50, doc.y).lineTo(545, doc.y).stroke();
    doc.moveDown(0.3);

    doc.font('Helvetica').fillColor('#0f172a');
    for (const item of sale.items) {
      const y = doc.y;
      const name = `${item.medicine.name}${item.medicine.dosage ? ' ' + item.medicine.dosage : ''}`;
      doc.text(name, 50, y, { width: 240 });
      doc.text(String(item.quantity), 300, y);
      doc.text(Number(item.unitPrice).toLocaleString('fr-FR'), 350, y);
      doc.text(Number(item.totalPrice).toLocaleString('fr-FR'), 450, y, { align: 'right' });
      doc.moveDown(0.8);
    }

    doc.moveDown(0.5);
    doc.strokeColor('#e2e8f0').moveTo(50, doc.y).lineTo(545, doc.y).stroke();
    doc.moveDown();

    // Totaux
    doc.fontSize(10);
    if (Number(sale.discount) > 0) {
      doc.text(`Remise: -${Number(sale.discount).toLocaleString('fr-FR')} MGA`, { align: 'right' });
    }
    doc.font('Helvetica-Bold').fontSize(12);
    doc.text(`TOTAL: ${Number(sale.totalAmount).toLocaleString('fr-FR')} MGA`, { align: 'right' });
    doc.font('Helvetica').fontSize(10);
    doc.text(`Mode de paiement: ${sale.paymentMethod}`, { align: 'right' });

    doc.moveDown(2);

    // Mentions légales
    if (settings?.legalMentions) {
      doc.fontSize(8).fillColor('#94a3b8').text(settings.legalMentions, { align: 'center' });
    } else {
      doc.fontSize(8).fillColor('#94a3b8').text(
        'Facture générée par PharmaGest Pro — Document non opposable fiscalement sans validation comptable.',
        { align: 'center' }
      );
    }

    doc.end();

    stream.on('finish', () => resolve(filePath));
    stream.on('error', reject);
  });
}

export async function getInvoiceFilePath(invoiceId: string) {
  const invoice = await prisma.invoice.findUnique({ where: { id: invoiceId } });
  if (!invoice || !invoice.pdfPath) throw new NotFoundError('Facture introuvable');
  if (!fs.existsSync(invoice.pdfPath)) throw new NotFoundError('Fichier PDF manquant');
  return invoice.pdfPath;
}
