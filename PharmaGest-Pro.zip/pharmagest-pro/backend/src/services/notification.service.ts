import { prisma } from '../utils/prisma.js';
import { NotificationType } from '@prisma/client';

export async function createNotification(data: {
  userId: string;
  type: NotificationType;
  title: string;
  message: string;
  reference?: string;
}) {
  // Éviter les doublons récents (même type + reference dans les 10 dernières minutes)
  if (data.reference) {
    const recent = await prisma.notification.findFirst({
      where: {
        userId: data.userId,
        type: data.type,
        reference: data.reference,
        createdAt: { gte: new Date(Date.now() - 10 * 60 * 1000) },
      },
    });
    if (recent) return recent;
  }

  return prisma.notification.create({
    data: {
      userId: data.userId,
      type: data.type,
      title: data.title,
      message: data.message,
      reference: data.reference,
    },
  });
}

export async function getUserNotifications(userId: string, unreadOnly = false) {
  const where: any = { userId };
  if (unreadOnly) where.isRead = false;

  return prisma.notification.findMany({
    where,
    orderBy: { createdAt: 'desc' },
    take: 50,
  });
}

export async function markAsRead(notificationId: string, userId: string) {
  return prisma.notification.updateMany({
    where: { id: notificationId, userId },
    data: { isRead: true },
  });
}

export async function markAllAsRead(userId: string) {
  return prisma.notification.updateMany({
    where: { userId, isRead: false },
    data: { isRead: true },
  });
}

export async function getUnreadCount(userId: string) {
  return prisma.notification.count({
    where: { userId, isRead: false },
  });
}

/**
 * Vérification périodique des alertes stock / péremption
 */
export async function checkStockAndExpiryAlerts() {
  const settings = await prisma.pharmacySettings.findFirst();
  const expiryDays = settings?.expiryAlertDays || 90;

  const medicines = await prisma.medicine.findMany({
    where: { isActive: true },
    include: {
      batches: {
        where: { isActive: true, quantity: { gt: 0 } },
      },
    },
  });

  const staff = await prisma.user.findMany({
    where: { role: { in: ['ADMIN', 'RESPONSABLE'] }, isActive: true },
  });

  for (const med of medicines) {
    const stock = med.batches
      .filter((b) => b.expiryDate > new Date())
      .reduce((s, b) => s + b.quantity, 0);

    if (stock === 0) {
      for (const u of staff) {
        await createNotification({
          userId: u.id,
          type: 'RUPTURE_STOCK',
          title: 'Rupture de stock',
          message: `${med.name} (${med.code}) est en rupture de stock`,
          reference: med.id,
        });
      }
    } else if (stock <= med.minStock) {
      for (const u of staff) {
        await createNotification({
          userId: u.id,
          type: 'STOCK_FAIBLE',
          title: 'Stock faible',
          message: `${med.name} : ${stock} unités restantes (seuil ${med.minStock})`,
          reference: med.id,
        });
      }
    }
  }

  // Péremption
  const limitDate = new Date();
  limitDate.setDate(limitDate.getDate() + expiryDays);

  const expiring = await prisma.batch.findMany({
    where: {
      isActive: true,
      quantity: { gt: 0 },
      expiryDate: { lte: limitDate, gt: new Date() },
    },
    include: { medicine: true },
  });

  for (const batch of expiring) {
    for (const u of staff) {
      await createNotification({
        userId: u.id,
        type: 'PEREMPTION_PROCHE',
        title: 'Péremption proche',
        message: `Lot ${batch.batchNumber} de ${batch.medicine.name} expire le ${batch.expiryDate.toLocaleDateString('fr-FR')}`,
        reference: batch.id,
      });
    }
  }

  const expired = await prisma.batch.findMany({
    where: {
      isActive: true,
      quantity: { gt: 0 },
      expiryDate: { lte: new Date() },
    },
    include: { medicine: true },
  });

  for (const batch of expired) {
    for (const u of staff) {
      await createNotification({
        userId: u.id,
        type: 'PERIME',
        title: 'Produit périmé',
        message: `Lot ${batch.batchNumber} de ${batch.medicine.name} est périmé`,
        reference: batch.id,
      });
    }
  }
}
