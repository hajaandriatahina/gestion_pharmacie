import { prisma } from '../utils/prisma.js';
import { AppError, NotFoundError } from '../utils/errors.js';
import { StockMovementType } from '@prisma/client';
import { Decimal } from '@prisma/client/runtime/library';

/**
 * Entrée de stock (réception fournisseur)
 */
export async function receiveStock(data: {
  medicineId: string;
  batchNumber: string;
  quantity: number;
  expiryDate: Date;
  purchasePrice: number;
  supplierId?: string;
  userId: string;
  receptionDate?: Date;
}) {
  if (data.quantity <= 0) throw new AppError('Quantité invalide');

  const medicine = await prisma.medicine.findUnique({ where: { id: data.medicineId } });
  if (!medicine) throw new NotFoundError('Médicament introuvable');

  return prisma.$transaction(async (tx) => {
    // Vérifier si le lot existe déjà
    let batch = await tx.batch.findUnique({
      where: {
        medicineId_batchNumber: {
          medicineId: data.medicineId,
          batchNumber: data.batchNumber,
        },
      },
    });

    if (batch) {
      batch = await tx.batch.update({
        where: { id: batch.id },
        data: {
          quantity: { increment: data.quantity },
          initialQty: { increment: data.quantity },
        },
      });
    } else {
      batch = await tx.batch.create({
        data: {
          medicineId: data.medicineId,
          batchNumber: data.batchNumber,
          quantity: data.quantity,
          initialQty: data.quantity,
          expiryDate: data.expiryDate,
          purchasePrice: new Decimal(data.purchasePrice),
          supplierId: data.supplierId,
          receptionDate: data.receptionDate || new Date(),
        },
      });
    }

    await tx.stockMovement.create({
      data: {
        type: StockMovementType.ENTREE,
        quantity: data.quantity,
        medicineId: data.medicineId,
        batchId: batch.id,
        userId: data.userId,
        reason: `Réception lot ${data.batchNumber}`,
      },
    });

    return batch;
  });
}

/**
 * Sélection FEFO des lots pour une quantité demandée
 */
export async function selectBatchesFEFO(
  medicineId: string,
  quantityNeeded: number,
  tx?: any
) {
  const client = tx || prisma;
  const batches = await client.batch.findMany({
    where: {
      medicineId,
      isActive: true,
      quantity: { gt: 0 },
      expiryDate: { gt: new Date() },
    },
    orderBy: { expiryDate: 'asc' },
  });

  let remaining = quantityNeeded;
  const selected: { batchId: string; quantity: number }[] = [];

  for (const batch of batches) {
    if (remaining <= 0) break;
    const take = Math.min(batch.quantity, remaining);
    selected.push({ batchId: batch.id, quantity: take });
    remaining -= take;
  }

  if (remaining > 0) {
    throw new AppError(
      `Stock insuffisant. Disponible: ${quantityNeeded - remaining}, demandé: ${quantityNeeded}`,
      400
    );
  }

  return selected;
}

/**
 * Sortie de stock (vente) avec FEFO et transaction
 */
export async function decreaseStockForSale(
  items: { medicineId: string; quantity: number }[],
  userId: string,
  saleId: string,
  tx: any
) {
  const results: { medicineId: string; batchId: string; quantity: number }[] = [];

  for (const item of items) {
    const selected = await selectBatchesFEFO(item.medicineId, item.quantity, tx);

    for (const sel of selected) {
      const updated = await tx.batch.update({
        where: { id: sel.batchId },
        data: { quantity: { decrement: sel.quantity } },
      });

      if (updated.quantity < 0) {
        throw new AppError('Erreur de stock concurrente détectée', 409);
      }

      await tx.stockMovement.create({
        data: {
          type: StockMovementType.SORTIE_VENTE,
          quantity: -sel.quantity,
          medicineId: item.medicineId,
          batchId: sel.batchId,
          userId,
          referenceId: saleId,
          reason: `Vente ${saleId}`,
        },
      });

      results.push({
        medicineId: item.medicineId,
        batchId: sel.batchId,
        quantity: sel.quantity,
      });
    }
  }

  return results;
}

export async function getLowStockMedicines() {
  const medicines = await prisma.medicine.findMany({
    where: { isActive: true },
    include: {
      batches: {
        where: { isActive: true, quantity: { gt: 0 }, expiryDate: { gt: new Date() } },
      },
    },
  });

  return medicines
    .map((m) => {
      const stock = m.batches.reduce((s, b) => s + b.quantity, 0);
      return {
        id: m.id,
        code: m.code,
        name: m.name,
        stock,
        minStock: m.minStock,
        isLow: stock <= m.minStock,
        isOut: stock === 0,
      };
    })
    .filter((m) => m.isLow)
    .sort((a, b) => a.stock - b.stock);
}

export async function getExpiringBatches(days = 90) {
  const limitDate = new Date();
  limitDate.setDate(limitDate.getDate() + days);

  return prisma.batch.findMany({
    where: {
      isActive: true,
      quantity: { gt: 0 },
      expiryDate: { lte: limitDate, gt: new Date() },
    },
    include: {
      medicine: { select: { id: true, name: true, code: true } },
      supplier: { select: { name: true } },
    },
    orderBy: { expiryDate: 'asc' },
  });
}

export async function getExpiredBatches() {
  return prisma.batch.findMany({
    where: {
      isActive: true,
      quantity: { gt: 0 },
      expiryDate: { lte: new Date() },
    },
    include: {
      medicine: { select: { id: true, name: true, code: true } },
    },
    orderBy: { expiryDate: 'asc' },
  });
}

export async function getStockMovements(params: {
  medicineId?: string;
  page?: number;
  limit?: number;
}) {
  const page = params.page || 1;
  const limit = Math.min(params.limit || 50, 100);
  const skip = (page - 1) * limit;

  const where: any = {};
  if (params.medicineId) where.medicineId = params.medicineId;

  const [items, total] = await Promise.all([
    prisma.stockMovement.findMany({
      where,
      include: {
        medicine: { select: { name: true, code: true } },
        batch: { select: { batchNumber: true } },
        user: { select: { firstName: true, lastName: true } },
      },
      orderBy: { createdAt: 'desc' },
      skip,
      take: limit,
    }),
    prisma.stockMovement.count({ where }),
  ]);

  return { items, total, page, limit };
}
