import { prisma } from '../utils/prisma.js';
import { AppError, NotFoundError } from '../utils/errors.js';
import { PaymentMethod } from '@prisma/client';
import { Decimal } from '@prisma/client/runtime/library';
import { decreaseStockForSale } from './stock.service.js';
import { generateInvoicePDF } from './invoice.service.js';
import { createNotification } from './notification.service.js';

function generateSaleNumber() {
  const date = new Date();
  const y = date.getFullYear().toString().slice(-2);
  const m = String(date.getMonth() + 1).padStart(2, '0');
  const d = String(date.getDate()).padStart(2, '0');
  const rand = Math.floor(Math.random() * 9000) + 1000;
  return `VTE-${y}${m}${d}-${rand}`;
}

export async function createSale(data: {
  sellerId: string;
  items: { medicineId: string; quantity: number; unitPrice?: number }[];
  paymentMethod: PaymentMethod;
  discount?: number;
  clientId?: string;
  orderId?: string;
  notes?: string;
}) {
  if (!data.items.length) throw new AppError('Panier vide');

  // Vérifier les médicaments et calculer les totaux
  const medicineIds = data.items.map((i) => i.medicineId);
  const medicines = await prisma.medicine.findMany({
    where: { id: { in: medicineIds }, isActive: true },
  });

  if (medicines.length !== medicineIds.length) {
    throw new AppError('Un ou plusieurs médicaments sont invalides ou inactifs');
  }

  const medicineMap = new Map(medicines.map((m) => [m.id, m]));

  let totalAmount = new Decimal(0);
  const preparedItems = data.items.map((item) => {
    const med = medicineMap.get(item.medicineId)!;
    const unitPrice = item.unitPrice !== undefined
      ? new Decimal(item.unitPrice)
      : med.salePrice;
    const totalPrice = unitPrice.mul(item.quantity);
    totalAmount = totalAmount.add(totalPrice);
    return {
      medicineId: item.medicineId,
      quantity: item.quantity,
      unitPrice,
      totalPrice,
      requiresPrescription: med.requiresPrescription,
    };
  });

  const discount = new Decimal(data.discount || 0);
  totalAmount = totalAmount.sub(discount);
  if (totalAmount.lt(0)) throw new AppError('Montant total invalide');

  // Vérifier ordonnances (simple alerte, pas de blocage hard ici)
  const needsPrescription = preparedItems.some((i) => i.requiresPrescription);

  return prisma.$transaction(async (tx) => {
    // 1. Créer la vente
    const saleNumber = generateSaleNumber();
    const sale = await tx.sale.create({
      data: {
        saleNumber,
        sellerId: data.sellerId,
        clientId: data.clientId,
        orderId: data.orderId,
        totalAmount,
        discount,
        paymentMethod: data.paymentMethod,
        notes: data.notes,
      },
    });

    // 2. Diminuer le stock (FEFO) + mouvements
    const stockResults = await decreaseStockForSale(
      preparedItems.map((i) => ({ medicineId: i.medicineId, quantity: i.quantity })),
      data.sellerId,
      sale.id,
      tx
    );

    // 3. Créer les lignes de vente
    for (const item of preparedItems) {
      const batchUsed = stockResults.find((s) => s.medicineId === item.medicineId);
      await tx.saleItem.create({
        data: {
          saleId: sale.id,
          medicineId: item.medicineId,
          batchId: batchUsed?.batchId,
          quantity: item.quantity,
          unitPrice: item.unitPrice,
          totalPrice: item.totalPrice,
        },
      });
    }

    // 4. Paiement
    await tx.payment.create({
      data: {
        saleId: sale.id,
        method: data.paymentMethod,
        amount: totalAmount,
      },
    });

    // 5. Facture
    const invoiceNumber = `FAC-${saleNumber.replace('VTE-', '')}`;
    const invoice = await tx.invoice.create({
      data: {
        invoiceNumber,
        saleId: sale.id,
      },
    });

    // 6. Si liée à une commande, mettre à jour le statut
    if (data.orderId) {
      await tx.order.update({
        where: { id: data.orderId },
        data: { status: 'TERMINEE', completedAt: new Date() },
      });
      await tx.orderStatusHistory.create({
        data: {
          orderId: data.orderId,
          status: 'TERMINEE',
          userId: data.sellerId,
          comment: 'Vente validée',
        },
      });
    }

    // Générer PDF en dehors de la transaction pure (après commit)
    return { sale, invoice, needsPrescription };
  }).then(async (result) => {
    // Générer le PDF
    try {
      const pdfPath = await generateInvoicePDF(result.sale.id);
      await prisma.invoice.update({
        where: { id: result.invoice.id },
        data: { pdfPath },
      });
    } catch (e) {
      console.error('Erreur génération PDF:', e);
    }

    // Notification
    await createNotification({
      userId: data.sellerId,
      type: 'VENTE_VALIDEE',
      title: 'Vente enregistrée',
      message: `Vente ${result.sale.saleNumber} — ${Number(result.sale.totalAmount).toLocaleString()} MGA`,
      reference: result.sale.id,
    });

    return getSaleById(result.sale.id);
  });
}

export async function getSaleById(id: string) {
  const sale = await prisma.sale.findUnique({
    where: { id },
    include: {
      seller: { select: { firstName: true, lastName: true } },
      items: {
        include: {
          medicine: { select: { name: true, code: true, dosage: true } },
        },
      },
      invoice: true,
      payment: true,
    },
  });
  if (!sale) throw new NotFoundError('Vente introuvable');

  return {
    ...sale,
    totalAmount: Number(sale.totalAmount),
    discount: Number(sale.discount),
    items: sale.items.map((i) => ({
      ...i,
      unitPrice: Number(i.unitPrice),
      totalPrice: Number(i.totalPrice),
    })),
  };
}

export async function listSales(params: {
  page?: number;
  limit?: number;
  from?: Date;
  to?: Date;
}) {
  const page = params.page || 1;
  const limit = Math.min(params.limit || 20, 100);
  const skip = (page - 1) * limit;

  const where: any = {};
  if (params.from || params.to) {
    where.createdAt = {};
    if (params.from) where.createdAt.gte = params.from;
    if (params.to) where.createdAt.lte = params.to;
  }

  const [items, total] = await Promise.all([
    prisma.sale.findMany({
      where,
      include: {
        seller: { select: { firstName: true, lastName: true } },
        invoice: { select: { invoiceNumber: true } },
        _count: { select: { items: true } },
      },
      orderBy: { createdAt: 'desc' },
      skip,
      take: limit,
    }),
    prisma.sale.count({ where }),
  ]);

  return {
    items: items.map((s) => ({
      ...s,
      totalAmount: Number(s.totalAmount),
      discount: Number(s.discount),
    })),
    total,
    page,
    limit,
  };
}

export async function getTodayStats() {
  const start = new Date();
  start.setHours(0, 0, 0, 0);
  const end = new Date();
  end.setHours(23, 59, 59, 999);

  const sales = await prisma.sale.findMany({
    where: { createdAt: { gte: start, lte: end } },
    select: { totalAmount: true },
  });

  const count = sales.length;
  const revenue = sales.reduce((sum, s) => sum + Number(s.totalAmount), 0);

  return { count, revenue };
}
