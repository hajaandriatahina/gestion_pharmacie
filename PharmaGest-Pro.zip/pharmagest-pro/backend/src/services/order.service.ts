import { prisma } from '../utils/prisma.js';
import { AppError, NotFoundError, ForbiddenError } from '../utils/errors.js';
import { OrderStatus } from '@prisma/client';
import { Decimal } from '@prisma/client/runtime/library';
import { createNotification } from './notification.service.js';

function generateOrderNumber() {
  const date = new Date();
  const y = date.getFullYear().toString().slice(-2);
  const m = String(date.getMonth() + 1).padStart(2, '0');
  const d = String(date.getDate()).padStart(2, '0');
  const rand = Math.floor(Math.random() * 9000) + 1000;
  return `CMD-${y}${m}${d}-${rand}`;
}

export async function createOrder(data: {
  clientId: string;
  items: { medicineId: string; quantity: number }[];
  notes?: string;
}) {
  if (!data.items.length) throw new AppError('Panier vide');

  const medicines = await prisma.medicine.findMany({
    where: { id: { in: data.items.map((i) => i.medicineId) }, isActive: true },
  });

  if (medicines.length !== data.items.length) {
    throw new AppError('Un ou plusieurs médicaments sont indisponibles');
  }

  const medMap = new Map(medicines.map((m) => [m.id, m]));
  let total = new Decimal(0);

  const orderItems = data.items.map((item) => {
    const med = medMap.get(item.medicineId)!;
    const unitPrice = med.salePrice;
    const totalPrice = unitPrice.mul(item.quantity);
    total = total.add(totalPrice);
    return {
      medicineId: item.medicineId,
      quantity: item.quantity,
      unitPrice,
      totalPrice,
    };
  });

  const order = await prisma.$transaction(async (tx) => {
    const orderNumber = generateOrderNumber();
    const created = await tx.order.create({
      data: {
        orderNumber,
        clientId: data.clientId,
        status: OrderStatus.EN_ATTENTE,
        totalAmount: total,
        notes: data.notes,
        items: {
          create: orderItems,
        },
      },
      include: {
        items: { include: { medicine: true } },
      },
    });

    await tx.orderStatusHistory.create({
      data: {
        orderId: created.id,
        status: OrderStatus.EN_ATTENTE,
        userId: data.clientId,
        comment: 'Commande soumise par le client',
      },
    });

    return created;
  });

  // Notifier les responsables
  const responsables = await prisma.user.findMany({
    where: { role: { in: ['ADMIN', 'RESPONSABLE'] }, isActive: true },
  });

  for (const r of responsables) {
    await createNotification({
      userId: r.id,
      type: 'NOUVELLE_COMMANDE',
      title: 'Nouvelle commande client',
      message: `Commande ${order.orderNumber} — ${Number(order.totalAmount).toLocaleString()} MGA`,
      reference: order.id,
    });
  }

  return getOrderById(order.id);
}

export async function getOrderById(id: string) {
  const order = await prisma.order.findUnique({
    where: { id },
    include: {
      client: { select: { id: true, firstName: true, lastName: true, email: true, phone: true } },
      items: {
        include: {
          medicine: { select: { id: true, name: true, code: true, dosage: true, salePrice: true } },
        },
      },
      statusHistory: {
        include: { user: { select: { firstName: true, lastName: true } } },
        orderBy: { createdAt: 'asc' },
      },
      sale: true,
    },
  });
  if (!order) throw new NotFoundError('Commande introuvable');

  return {
    ...order,
    totalAmount: Number(order.totalAmount),
    items: order.items.map((i) => ({
      ...i,
      unitPrice: Number(i.unitPrice),
      totalPrice: Number(i.totalPrice),
      medicine: {
        ...i.medicine,
        salePrice: Number(i.medicine.salePrice),
      },
    })),
  };
}

export async function updateOrderStatus(
  orderId: string,
  newStatus: OrderStatus,
  userId: string,
  comment?: string,
  refusalReason?: string
) {
  const order = await prisma.order.findUnique({ where: { id: orderId } });
  if (!order) throw new NotFoundError('Commande introuvable');

  // Transitions autorisées (simplifiées)
  const allowed: Record<string, OrderStatus[]> = {
    EN_ATTENTE: ['EN_VERIFICATION', 'ACCEPTEE', 'REFUSEE', 'ANNULEE'],
    EN_VERIFICATION: ['ACCEPTEE', 'REFUSEE'],
    ACCEPTEE: ['EN_PREPARATION', 'REFUSEE'],
    EN_PREPARATION: ['PRETE', 'REFUSEE'],
    PRETE: ['TERMINEE'],
  };

  const currentAllowed = allowed[order.status] || [];
  if (!currentAllowed.includes(newStatus) && !['ADMIN'].includes('ADMIN')) {
    // On laisse plus flexible pour l'admin/responsable
  }

  const updated = await prisma.$transaction(async (tx) => {
    const data: any = { status: newStatus };
    if (newStatus === 'ACCEPTEE') data.validatedAt = new Date();
    if (newStatus === 'EN_PREPARATION' || newStatus === 'PRETE') data.preparedAt = new Date();
    if (newStatus === 'TERMINEE') data.completedAt = new Date();
    if (newStatus === 'REFUSEE' && refusalReason) data.refusalReason = refusalReason;

    const o = await tx.order.update({
      where: { id: orderId },
      data,
    });

    await tx.orderStatusHistory.create({
      data: {
        orderId,
        status: newStatus,
        userId,
        comment: comment || refusalReason,
      },
    });

    return o;
  });

  // Notifications client
  const notifMap: Partial<Record<OrderStatus, { type: any; title: string }>> = {
    ACCEPTEE: { type: 'COMMANDE_ACCEPTEE', title: 'Commande acceptée' },
    REFUSEE: { type: 'COMMANDE_REFUSEE', title: 'Commande refusée' },
    PRETE: { type: 'COMMANDE_PRETE', title: 'Commande prête' },
  };

  const notif = notifMap[newStatus];
  if (notif) {
    await createNotification({
      userId: order.clientId,
      type: notif.type,
      title: notif.title,
      message: `Votre commande ${order.orderNumber} est passée au statut : ${newStatus}${refusalReason ? ` — Motif : ${refusalReason}` : ''}`,
      reference: orderId,
    });
  }

  return getOrderById(orderId);
}

export async function listOrders(params: {
  status?: OrderStatus;
  clientId?: string;
  page?: number;
  limit?: number;
}) {
  const page = params.page || 1;
  const limit = Math.min(params.limit || 20, 100);
  const skip = (page - 1) * limit;

  const where: any = {};
  if (params.status) where.status = params.status;
  if (params.clientId) where.clientId = params.clientId;

  const [items, total] = await Promise.all([
    prisma.order.findMany({
      where,
      include: {
        client: { select: { firstName: true, lastName: true, email: true } },
        _count: { select: { items: true } },
      },
      orderBy: { createdAt: 'desc' },
      skip,
      take: limit,
    }),
    prisma.order.count({ where }),
  ]);

  return {
    items: items.map((o) => ({
      ...o,
      totalAmount: Number(o.totalAmount),
    })),
    total,
    page,
    limit,
  };
}
