import { prisma } from '../utils/prisma.js';
import { AppError, NotFoundError, ConflictError } from '../utils/errors.js';
import { Decimal } from '@prisma/client/runtime/library';

export async function listMedicines(params: {
  search?: string;
  categoryId?: string;
  isActive?: boolean;
  page?: number;
  limit?: number;
}) {
  const page = params.page || 1;
  const limit = Math.min(params.limit || 20, 100);
  const skip = (page - 1) * limit;

  const where: any = {};
  if (params.isActive !== undefined) where.isActive = params.isActive;
  if (params.categoryId) where.categoryId = params.categoryId;
  if (params.search) {
    where.OR = [
      { name: { contains: params.search } },
      { code: { contains: params.search } },
      { activeIngredient: { contains: params.search } },
    ];
  }

  const [items, total] = await Promise.all([
    prisma.medicine.findMany({
      where,
      include: {
        category: true,
        batches: {
          where: { isActive: true, quantity: { gt: 0 } },
          orderBy: { expiryDate: 'asc' },
        },
      },
      orderBy: { name: 'asc' },
      skip,
      take: limit,
    }),
    prisma.medicine.count({ where }),
  ]);

  // Calculer stock total pour chaque médicament
  const enriched = items.map((m) => {
    const stock = m.batches.reduce((sum, b) => sum + b.quantity, 0);
    return {
      ...m,
      stock,
      purchasePrice: Number(m.purchasePrice),
      salePrice: Number(m.salePrice),
      batches: m.batches.map((b) => ({
        ...b,
        purchasePrice: Number(b.purchasePrice),
      })),
    };
  });

  return { items: enriched, total, page, limit, totalPages: Math.ceil(total / limit) };
}

export async function getMedicineById(id: string) {
  const medicine = await prisma.medicine.findUnique({
    where: { id },
    include: {
      category: true,
      batches: {
        where: { isActive: true },
        orderBy: { expiryDate: 'asc' },
        include: { supplier: true },
      },
    },
  });
  if (!medicine) throw new NotFoundError('Médicament introuvable');

  const stock = medicine.batches.reduce((s, b) => s + b.quantity, 0);
  return {
    ...medicine,
    stock,
    purchasePrice: Number(medicine.purchasePrice),
    salePrice: Number(medicine.salePrice),
  };
}

export async function createMedicine(data: {
  code: string;
  name: string;
  activeIngredient?: string;
  form?: string;
  dosage?: string;
  laboratory?: string;
  purchasePrice: number;
  salePrice: number;
  minStock?: number;
  description?: string;
  requiresPrescription?: boolean;
  categoryId?: string;
}) {
  const existing = await prisma.medicine.findUnique({ where: { code: data.code } });
  if (existing) throw new ConflictError('Ce code produit existe déjà');

  const medicine = await prisma.medicine.create({
    data: {
      code: data.code,
      name: data.name,
      activeIngredient: data.activeIngredient,
      form: data.form,
      dosage: data.dosage,
      laboratory: data.laboratory,
      purchasePrice: new Decimal(data.purchasePrice),
      salePrice: new Decimal(data.salePrice),
      minStock: data.minStock ?? 10,
      description: data.description,
      requiresPrescription: data.requiresPrescription ?? false,
      categoryId: data.categoryId,
    },
    include: { category: true },
  });

  return {
    ...medicine,
    purchasePrice: Number(medicine.purchasePrice),
    salePrice: Number(medicine.salePrice),
    stock: 0,
  };
}

export async function updateMedicine(id: string, data: Partial<{
  code: string;
  name: string;
  activeIngredient: string;
  form: string;
  dosage: string;
  laboratory: string;
  purchasePrice: number;
  salePrice: number;
  minStock: number;
  description: string;
  requiresPrescription: boolean;
  categoryId: string | null;
  isActive: boolean;
}>) {
  await getMedicineById(id);

  const updateData: any = { ...data };
  if (data.purchasePrice !== undefined) updateData.purchasePrice = new Decimal(data.purchasePrice);
  if (data.salePrice !== undefined) updateData.salePrice = new Decimal(data.salePrice);

  const medicine = await prisma.medicine.update({
    where: { id },
    data: updateData,
    include: { category: true },
  });

  return {
    ...medicine,
    purchasePrice: Number(medicine.purchasePrice),
    salePrice: Number(medicine.salePrice),
  };
}

export async function searchMedicinesForPOS(query: string) {
  if (!query || query.length < 1) return [];

  const medicines = await prisma.medicine.findMany({
    where: {
      isActive: true,
      OR: [
        { name: { contains: query } },
        { code: { contains: query } },
        { activeIngredient: { contains: query } },
      ],
    },
    include: {
      batches: {
        where: {
          isActive: true,
          quantity: { gt: 0 },
          expiryDate: { gt: new Date() },
        },
        orderBy: { expiryDate: 'asc' },
      },
    },
    take: 15,
  });

  return medicines.map((m) => {
    const stock = m.batches.reduce((s, b) => s + b.quantity, 0);
    return {
      id: m.id,
      code: m.code,
      name: m.name,
      dosage: m.dosage,
      form: m.form,
      salePrice: Number(m.salePrice),
      stock,
      requiresPrescription: m.requiresPrescription,
      nearestExpiry: m.batches[0]?.expiryDate || null,
    };
  });
}
