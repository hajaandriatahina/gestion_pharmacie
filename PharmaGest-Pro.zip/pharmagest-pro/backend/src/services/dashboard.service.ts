import { prisma } from '../utils/prisma.js';

export async function getDashboardStats() {
  const now = new Date();
  const startOfDay = new Date(now);
  startOfDay.setHours(0, 0, 0, 0);
  const endOfDay = new Date(now);
  endOfDay.setHours(23, 59, 59, 999);

  // 7 derniers jours
  const sevenDaysAgo = new Date(now);
  sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 6);
  sevenDaysAgo.setHours(0, 0, 0, 0);

  // Médicaments actifs + stock
  const medicines = await prisma.medicine.findMany({
    where: { isActive: true },
    include: {
      batches: {
        where: { isActive: true, quantity: { gt: 0 }, expiryDate: { gt: now } },
      },
    },
  });

  let stockValue = 0;
  let lowStockCount = 0;
  for (const m of medicines) {
    const qty = m.batches.reduce((s, b) => s + b.quantity, 0);
    const avgCost = m.batches.length
      ? m.batches.reduce((s, b) => s + Number(b.purchasePrice) * b.quantity, 0) / qty || Number(m.purchasePrice)
      : Number(m.purchasePrice);
    stockValue += qty * (qty > 0 ? avgCost : 0);
    if (qty <= m.minStock) lowStockCount++;
  }

  // Péremption 90 jours
  const expiryLimit = new Date();
  expiryLimit.setDate(expiryLimit.getDate() + 90);
  const expiringCount = await prisma.batch.count({
    where: {
      isActive: true,
      quantity: { gt: 0 },
      expiryDate: { lte: expiryLimit, gt: now },
    },
  });

  // Commandes en attente
  const pendingOrders = await prisma.order.count({
    where: { status: { in: ['EN_ATTENTE', 'EN_VERIFICATION'] } },
  });

  // Ventes du jour
  const todaySales = await prisma.sale.findMany({
    where: { createdAt: { gte: startOfDay, lte: endOfDay } },
    select: { totalAmount: true },
  });
  const todayCount = todaySales.length;
  const todayRevenue = todaySales.reduce((s, v) => s + Number(v.totalAmount), 0);

  // Graphique 7 jours
  const salesLast7 = await prisma.sale.findMany({
    where: { createdAt: { gte: sevenDaysAgo } },
    select: { totalAmount: true, createdAt: true },
  });

  const dailyMap: Record<string, number> = {};
  for (let i = 0; i < 7; i++) {
    const d = new Date(sevenDaysAgo);
    d.setDate(d.getDate() + i);
    const key = d.toISOString().slice(0, 10);
    dailyMap[key] = 0;
  }
  for (const s of salesLast7) {
    const key = s.createdAt.toISOString().slice(0, 10);
    if (dailyMap[key] !== undefined) dailyMap[key] += Number(s.totalAmount);
  }
  const salesChart = Object.entries(dailyMap).map(([date, amount]) => ({ date, amount }));

  // Top médicaments
  const topItems = await prisma.saleItem.groupBy({
    by: ['medicineId'],
    _sum: { quantity: true },
    orderBy: { _sum: { quantity: 'desc' } },
    take: 5,
  });

  const topMedicineIds = topItems.map((t) => t.medicineId);
  const topMeds = await prisma.medicine.findMany({
    where: { id: { in: topMedicineIds } },
    select: { id: true, name: true },
  });
  const topMap = new Map(topMeds.map((m) => [m.id, m.name]));
  const topMedicines = topItems.map((t) => ({
    name: topMap.get(t.medicineId) || 'Inconnu',
    quantity: t._sum.quantity || 0,
  }));

  // Dernières ventes
  const recentSales = await prisma.sale.findMany({
    take: 5,
    orderBy: { createdAt: 'desc' },
    include: {
      seller: { select: { firstName: true, lastName: true } },
    },
  });

  // Dernières commandes
  const recentOrders = await prisma.order.findMany({
    take: 5,
    orderBy: { createdAt: 'desc' },
    include: {
      client: { select: { firstName: true, lastName: true } },
    },
  });

  return {
    activeMedicines: medicines.length,
    stockValue: Math.round(stockValue),
    lowStockCount,
    expiringCount,
    pendingOrders,
    todaySalesCount: todayCount,
    todayRevenue: Math.round(todayRevenue),
    salesChart,
    topMedicines,
    recentSales: recentSales.map((s) => ({
      id: s.id,
      saleNumber: s.saleNumber,
      totalAmount: Number(s.totalAmount),
      seller: `${s.seller.firstName} ${s.seller.lastName}`,
      createdAt: s.createdAt,
    })),
    recentOrders: recentOrders.map((o) => ({
      id: o.id,
      orderNumber: o.orderNumber,
      status: o.status,
      totalAmount: Number(o.totalAmount),
      client: `${o.client.firstName} ${o.client.lastName}`,
      createdAt: o.createdAt,
    })),
  };
}
