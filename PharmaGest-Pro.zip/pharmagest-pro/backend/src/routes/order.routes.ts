import { Router } from 'express';
import * as controller from '../controllers/order.controller.js';
import { authenticate, authorize } from '../middlewares/auth.js';

const router = Router();

router.use(authenticate);

router.post('/', authorize('CLIENT'), controller.create);
router.get('/', controller.list);
router.get('/:id', controller.getById);
router.patch('/:id/status', authorize('ADMIN', 'RESPONSABLE'), controller.updateStatus);

export default router;
