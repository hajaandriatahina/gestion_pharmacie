import { Router } from 'express';
import authRoutes from './auth.routes.js';
import medicineRoutes from './medicine.routes.js';
import stockRoutes from './stock.routes.js';
import saleRoutes from './sale.routes.js';
import orderRoutes from './order.routes.js';
import dashboardRoutes from './dashboard.routes.js';
import notificationRoutes from './notification.routes.js';
import categoryRoutes from './category.routes.js';
import userRoutes from './user.routes.js';
import invoiceRoutes from './invoice.routes.js';

const router = Router();

router.use('/auth', authRoutes);
router.use('/medicines', medicineRoutes);
router.use('/stock', stockRoutes);
router.use('/sales', saleRoutes);
router.use('/orders', orderRoutes);
router.use('/dashboard', dashboardRoutes);
router.use('/notifications', notificationRoutes);
router.use('/categories', categoryRoutes);
router.use('/users', userRoutes);
router.use('/invoices', invoiceRoutes);

router.get('/health', (_req, res) => {
  res.json({ success: true, message: 'PharmaGest Pro API is running', timestamp: new Date().toISOString() });
});

export default router;
