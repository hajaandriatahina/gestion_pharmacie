import { Router } from 'express';
import * as controller from '../controllers/sale.controller.js';
import { authenticate, authorize } from '../middlewares/auth.js';

const router = Router();

router.use(authenticate);
router.use(authorize('ADMIN', 'RESPONSABLE'));

router.post('/', controller.create);
router.get('/', controller.list);
router.get('/:id', controller.getById);

export default router;
