import { Router } from 'express';
import { authenticate } from '../middlewares/auth.js';
import { getInvoiceFilePath } from '../services/invoice.service.js';
import { AuthRequest } from '../middlewares/auth.js';
import { Response, NextFunction } from 'express';
import path from 'path';

const router = Router();

router.use(authenticate);

router.get('/:id/download', async (req: AuthRequest, res: Response, next: NextFunction) => {
  try {
    const filePath = await getInvoiceFilePath(req.params.id);
    res.download(filePath, path.basename(filePath));
  } catch (err) {
    next(err);
  }
});

export default router;
