import { Router } from 'express';
import * as controller from '../controllers/dashboard.controller.js';
import { authenticate, authorize } from '../middlewares/auth.js';

const router = Router();

router.use(authenticate);
router.use(authorize('ADMIN', 'RESPONSABLE'));
router.get('/stats', controller.stats);

export default router;
