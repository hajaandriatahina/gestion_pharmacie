import { Router } from 'express';
import * as controller from '../controllers/stock.controller.js';
import { authenticate, authorize } from '../middlewares/auth.js';

const router = Router();

router.use(authenticate);
router.use(authorize('ADMIN', 'RESPONSABLE'));

router.post('/receive', controller.receive);
router.get('/low', controller.lowStock);
router.get('/expiring', controller.expiring);
router.get('/expired', controller.expired);
router.get('/movements', controller.movements);

export default router;
