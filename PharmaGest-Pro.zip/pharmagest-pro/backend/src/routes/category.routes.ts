import { Router } from 'express';
import { prisma } from '../utils/prisma.js';
import { authenticate, authorize, AuthRequest } from '../middlewares/auth.js';
import { Response, NextFunction } from 'express';
import { z } from 'zod';

const router = Router();

router.use(authenticate);

router.get('/', async (_req, res, next) => {
  try {
    const categories = await prisma.category.findMany({
      where: { isActive: true },
      orderBy: { name: 'asc' },
    });
    res.json({ success: true, data: categories });
  } catch (err) {
    next(err);
  }
});

router.post('/', authorize('ADMIN', 'RESPONSABLE'), async (req: AuthRequest, res: Response, next: NextFunction) => {
  try {
    const schema = z.object({ name: z.string().min(2), description: z.string().optional() });
    const data = schema.parse(req.body);
    const cat = await prisma.category.create({ data });
    res.status(201).json({ success: true, data: cat });
  } catch (err) {
    next(err);
  }
});

export default router;
