import { Router } from 'express';
import * as controller from '../controllers/medicine.controller.js';
import { authenticate, authorize } from '../middlewares/auth.js';

const router = Router();

router.use(authenticate);

router.get('/search', authorize('ADMIN', 'RESPONSABLE'), controller.searchPOS);
router.get('/', controller.list);
router.get('/:id', controller.getById);
router.post('/', authorize('ADMIN', 'RESPONSABLE'), controller.create);
router.put('/:id', authorize('ADMIN', 'RESPONSABLE'), controller.update);

export default router;
