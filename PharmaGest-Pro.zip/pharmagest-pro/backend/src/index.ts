import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import routes from './routes/index.js';
import { errorHandler } from './middlewares/errorHandler.js';
import { checkStockAndExpiryAlerts } from './services/notification.service.js';

const app = express();
const PORT = process.env.PORT || 5000;

app.use(helmet());
app.use(cors({
  origin: process.env.FRONTEND_URL || 'http://localhost:5173',
  credentials: true,
}));
app.use(express.json({ limit: '2mb' }));
app.use(express.urlencoded({ extended: true }));

app.use('/api', routes);

app.use(errorHandler);

app.listen(PORT, () => {
  console.log(`🚀 PharmaGest Pro API démarrée sur http://localhost:${PORT}`);
  console.log(`📋 Health: http://localhost:${PORT}/api/health`);

  // Vérification périodique des alertes (toutes les heures)
  setInterval(() => {
    checkStockAndExpiryAlerts().catch(console.error);
  }, 60 * 60 * 1000);

  // Première vérification 30s après démarrage
  setTimeout(() => {
    checkStockAndExpiryAlerts().catch(console.error);
  }, 30000);
});
