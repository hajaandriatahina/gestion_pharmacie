import { Response, NextFunction } from 'express';
import { z } from 'zod';
import * as orderService from '../services/order.service.js';
import { AuthRequest } from '../middlewares/auth.js';
import { OrderStatus } from '@prisma/client';
import { ForbiddenError } from '../utils/errors.js';

const createSchema = z.object({
  items: z.array(z.object({
    medicineId: z.string(),
    quantity: z.number().int().positive(),
  })).min(1),
  notes: z.string().optional(),
});

export async function create(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const data = createSchema.parse(req.body);
    const order = await orderService.createOrder({
      clientId: req.user!.id,
      items: data.items,
      notes: data.notes,
    });
    res.status(201).json({ success: true, data: order });
  } catch (err) {
    next(err);
  }
}

export async function getById(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const order = await orderService.getOrderById(req.params.id);
    // Client ne voit que ses commandes
    if (req.user!.role === 'CLIENT' && order.client.id !== req.user!.id) {
      throw new ForbiddenError();
    }
    res.json({ success: true, data: order });
  } catch (err) {
    next(err);
  }
}

export async function list(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const params: any = {
      page: Number(req.query.page) || 1,
      limit: Number(req.query.limit) || 20,
      status: req.query.status as OrderStatus | undefined,
    };
    if (req.user!.role === 'CLIENT') {
      params.clientId = req.user!.id;
    }
    const result = await orderService.listOrders(params);
    res.json({ success: true, data: result });
  } catch (err) {
    next(err);
  }
}

const statusSchema = z.object({
  status: z.nativeEnum(OrderStatus),
  comment: z.string().optional(),
  refusalReason: z.string().optional(),
});

export async function updateStatus(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const data = statusSchema.parse(req.body);
    const order = await orderService.updateOrderStatus(
      req.params.id,
      data.status,
      req.user!.id,
      data.comment,
      data.refusalReason
    );
    res.json({ success: true, data: order });
  } catch (err) {
    next(err);
  }
}
