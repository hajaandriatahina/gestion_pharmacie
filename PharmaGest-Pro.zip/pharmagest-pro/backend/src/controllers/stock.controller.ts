import { Response, NextFunction } from 'express';
import { z } from 'zod';
import * as stockService from '../services/stock.service.js';
import { AuthRequest } from '../middlewares/auth.js';

const receiveSchema = z.object({
  medicineId: z.string(),
  batchNumber: z.string().min(1),
  quantity: z.number().int().positive(),
  expiryDate: z.string().or(z.date()),
  purchasePrice: z.number().positive(),
  supplierId: z.string().optional(),
});

export async function receive(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const data = receiveSchema.parse(req.body);
    const batch = await stockService.receiveStock({
      ...data,
      expiryDate: new Date(data.expiryDate),
      userId: req.user!.id,
    });
    res.status(201).json({ success: true, data: batch });
  } catch (err) {
    next(err);
  }
}

export async function lowStock(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const items = await stockService.getLowStockMedicines();
    res.json({ success: true, data: items });
  } catch (err) {
    next(err);
  }
}

export async function expiring(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const days = Number(req.query.days) || 90;
    const items = await stockService.getExpiringBatches(days);
    res.json({ success: true, data: items });
  } catch (err) {
    next(err);
  }
}

export async function expired(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const items = await stockService.getExpiredBatches();
    res.json({ success: true, data: items });
  } catch (err) {
    next(err);
  }
}

export async function movements(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const result = await stockService.getStockMovements({
      medicineId: req.query.medicineId as string,
      page: Number(req.query.page) || 1,
      limit: Number(req.query.limit) || 50,
    });
    res.json({ success: true, data: result });
  } catch (err) {
    next(err);
  }
}
