import { Response, NextFunction } from 'express';
import { z } from 'zod';
import * as medicineService from '../services/medicine.service.js';
import { AuthRequest } from '../middlewares/auth.js';

export async function list(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const result = await medicineService.listMedicines({
      search: req.query.search as string,
      categoryId: req.query.categoryId as string,
      isActive: req.query.isActive === 'true' ? true : req.query.isActive === 'false' ? false : undefined,
      page: Number(req.query.page) || 1,
      limit: Number(req.query.limit) || 20,
    });
    res.json({ success: true, data: result });
  } catch (err) {
    next(err);
  }
}

export async function getById(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const medicine = await medicineService.getMedicineById(req.params.id);
    res.json({ success: true, data: medicine });
  } catch (err) {
    next(err);
  }
}

const createSchema = z.object({
  code: z.string().min(1),
  name: z.string().min(2),
  activeIngredient: z.string().optional(),
  form: z.string().optional(),
  dosage: z.string().optional(),
  laboratory: z.string().optional(),
  purchasePrice: z.number().positive(),
  salePrice: z.number().positive(),
  minStock: z.number().int().min(0).optional(),
  description: z.string().optional(),
  requiresPrescription: z.boolean().optional(),
  categoryId: z.string().optional(),
});

export async function create(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const data = createSchema.parse(req.body);
    const medicine = await medicineService.createMedicine(data);
    res.status(201).json({ success: true, data: medicine });
  } catch (err) {
    next(err);
  }
}

export async function update(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const medicine = await medicineService.updateMedicine(req.params.id, req.body);
    res.json({ success: true, data: medicine });
  } catch (err) {
    next(err);
  }
}

export async function searchPOS(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const q = (req.query.q as string) || '';
    const results = await medicineService.searchMedicinesForPOS(q);
    res.json({ success: true, data: results });
  } catch (err) {
    next(err);
  }
}
