import { Response, NextFunction } from 'express';
import * as notificationService from '../services/notification.service.js';
import { AuthRequest } from '../middlewares/auth.js';

export async function list(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const unreadOnly = req.query.unread === 'true';
    const items = await notificationService.getUserNotifications(req.user!.id, unreadOnly);
    res.json({ success: true, data: items });
  } catch (err) {
    next(err);
  }
}

export async function unreadCount(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const count = await notificationService.getUnreadCount(req.user!.id);
    res.json({ success: true, data: { count } });
  } catch (err) {
    next(err);
  }
}

export async function markRead(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    await notificationService.markAsRead(req.params.id, req.user!.id);
    res.json({ success: true });
  } catch (err) {
    next(err);
  }
}

export async function markAllRead(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    await notificationService.markAllAsRead(req.user!.id);
    res.json({ success: true });
  } catch (err) {
    next(err);
  }
}
