import { Response, NextFunction } from 'express';
import { z } from 'zod';
import * as saleService from '../services/sale.service.js';
import { AuthRequest } from '../middlewares/auth.js';
import { PaymentMethod } from '@prisma/client';

const createSaleSchema = z.object({
  items: z.array(z.object({
    medicineId: z.string(),
    quantity: z.number().int().positive(),
    unitPrice: z.number().positive().optional(),
  })).min(1),
  paymentMethod: z.nativeEnum(PaymentMethod),
  discount: z.number().min(0).optional(),
  clientId: z.string().optional(),
  orderId: z.string().optional(),
  notes: z.string().optional(),
});

export async function create(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const data = createSaleSchema.parse(req.body);
    const sale = await saleService.createSale({
      ...data,
      sellerId: req.user!.id,
    });
    res.status(201).json({ success: true, data: sale });
  } catch (err) {
    next(err);
  }
}

export async function getById(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const sale = await saleService.getSaleById(req.params.id);
    res.json({ success: true, data: sale });
  } catch (err) {
    next(err);
  }
}

export async function list(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const result = await saleService.listSales({
      page: Number(req.query.page) || 1,
      limit: Number(req.query.limit) || 20,
    });
    res.json({ success: true, data: result });
  } catch (err) {
    next(err);
  }
}
