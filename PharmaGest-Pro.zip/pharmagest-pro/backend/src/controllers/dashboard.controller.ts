import { Response, NextFunction } from 'express';
import * as dashboardService from '../services/dashboard.service.js';
import { AuthRequest } from '../middlewares/auth.js';

export async function stats(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const data = await dashboardService.getDashboardStats();
    res.json({ success: true, data });
  } catch (err) {
    next(err);
  }
}
