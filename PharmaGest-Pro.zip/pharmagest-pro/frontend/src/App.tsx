import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import AppLayout from './layouts/AppLayout';
import Login from './pages/Login';
import Register from './pages/Register';
import Dashboard from './pages/Dashboard';
import POS from './pages/POS';
import Medicines from './pages/Medicines';
import Stock from './pages/Stock';
import Orders from './pages/Orders';
import Sales from './pages/Sales';
import Catalog from './pages/Catalog';
import Cart from './pages/Cart';
import Users from './pages/Users';
import Notifications from './pages/Notifications';

function PrivateRoute({ children, roles }: { children: React.ReactNode; roles?: string[] }) {
  const { user, loading } = useAuth();
  if (loading) {
    return (
      <div className="flex h-screen items-center justify-center">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary-600 border-t-transparent" />
      </div>
    );
  }
  if (!user) return <Navigate to="/login" replace />;
  if (roles && !roles.includes(user.role)) {
    return <Navigate to="/" replace />;
  }
  return <>{children}</>;
}

function HomeRedirect() {
  const { user } = useAuth();
  if (!user) return <Navigate to="/login" replace />;
  if (user.role === 'CLIENT') return <Navigate to="/catalog" replace />;
  return <Navigate to="/dashboard" replace />;
}

export default function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />

          <Route
            path="/"
            element={
              <PrivateRoute>
                <AppLayout />
              </PrivateRoute>
            }
          >
            <Route index element={<HomeRedirect />} />
            <Route path="dashboard" element={<PrivateRoute roles={['ADMIN', 'RESPONSABLE']}><Dashboard /></PrivateRoute>} />
            <Route path="pos" element={<PrivateRoute roles={['ADMIN', 'RESPONSABLE']}><POS /></PrivateRoute>} />
            <Route path="medicines" element={<PrivateRoute roles={['ADMIN', 'RESPONSABLE']}><Medicines /></PrivateRoute>} />
            <Route path="stock" element={<PrivateRoute roles={['ADMIN', 'RESPONSABLE']}><Stock /></PrivateRoute>} />
            <Route path="orders" element={<PrivateRoute roles={['ADMIN', 'RESPONSABLE']}><Orders /></PrivateRoute>} />
            <Route path="sales" element={<PrivateRoute roles={['ADMIN', 'RESPONSABLE']}><Sales /></PrivateRoute>} />
            <Route path="users" element={<PrivateRoute roles={['ADMIN']}><Users /></PrivateRoute>} />
            <Route path="catalog" element={<PrivateRoute roles={['CLIENT']}><Catalog /></PrivateRoute>} />
            <Route path="cart" element={<PrivateRoute roles={['CLIENT']}><Cart /></PrivateRoute>} />
            <Route path="my-orders" element={<PrivateRoute roles={['CLIENT']}><Orders /></PrivateRoute>} />
            <Route path="notifications" element={<Notifications />} />
          </Route>

          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </BrowserRouter>
    </AuthProvider>
  );
}
