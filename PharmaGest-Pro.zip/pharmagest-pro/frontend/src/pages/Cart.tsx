import { useState, useEffect } from 'react';
import { orderApi } from '../services/api';
import { useNavigate } from 'react-router-dom';
import { Trash2, Minus, Plus, Send } from 'lucide-react';

export default function Cart() {
  const [cart, setCart] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [msg, setMsg] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    try {
      setCart(JSON.parse(localStorage.getItem('clientCart') || '[]'));
    } catch {
      setCart([]);
    }
  }, []);

  const save = (c: any[]) => {
    setCart(c);
    localStorage.setItem('clientCart', JSON.stringify(c));
  };

  const updateQty = (id: string, delta: number) => {
    save(
      cart
        .map((c) => (c.medicineId === id ? { ...c, quantity: c.quantity + delta } : c))
        .filter((c) => c.quantity > 0)
    );
  };

  const remove = (id: string) => {
    save(cart.filter((c) => c.medicineId !== id));
  };

  const total = cart.reduce((s, c) => s + c.unitPrice * c.quantity, 0);

  const submit = async () => {
    if (!cart.length) return;
    setLoading(true);
    setMsg('');
    try {
      await orderApi.create({
        items: cart.map((c) => ({
          medicineId: c.medicineId,
          quantity: c.quantity,
        })),
      });
      localStorage.removeItem('clientCart');
      setCart([]);
      setMsg('Commande soumise avec succès ! La pharmacie va la traiter.');
      setTimeout(() => navigate('/my-orders'), 2000);
    } catch (err: any) {
      setMsg(err.response?.data?.message || 'Erreur lors de la soumission');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-4 max-w-2xl">
      <div>
        <h1 className="text-2xl font-bold text-slate-900">Mon panier</h1>
        <p className="text-slate-500">Vérifiez votre commande avant de la soumettre</p>
      </div>

      {msg && (
        <div className={`rounded-lg px-4 py-3 text-sm ${msg.includes('succès') ? 'bg-emerald-50 text-emerald-700' : 'bg-red-50 text-red-700'}`}>
          {msg}
        </div>
      )}

      {cart.length === 0 ? (
        <div className="card text-center py-12 text-slate-400">
          <p>Votre panier est vide</p>
        </div>
      ) : (
        <div className="card space-y-4">
          {cart.map((item) => (
            <div key={item.medicineId} className="flex items-center gap-3 border-b border-slate-100 pb-3">
              <div className="flex-1">
                <p className="font-medium">{item.name}</p>
                <p className="text-sm text-slate-500">{item.unitPrice.toLocaleString()} MGA</p>
              </div>
              <div className="flex items-center gap-1">
                <button className="rounded p-1 hover:bg-slate-100" onClick={() => updateQty(item.medicineId, -1)}>
                  <Minus size={14} />
                </button>
                <span className="w-6 text-center text-sm">{item.quantity}</span>
                <button className="rounded p-1 hover:bg-slate-100" onClick={() => updateQty(item.medicineId, 1)}>
                  <Plus size={14} />
                </button>
              </div>
              <p className="w-24 text-right font-medium">
                {(item.unitPrice * item.quantity).toLocaleString()}
              </p>
              <button className="text-red-500 hover:bg-red-50 rounded p-1" onClick={() => remove(item.medicineId)}>
                <Trash2 size={16} />
              </button>
            </div>
          ))}

          <div className="flex items-center justify-between pt-2">
            <span className="text-lg font-bold">Total : {total.toLocaleString()} MGA</span>
            <button className="btn-primary" disabled={loading} onClick={submit}>
              <Send size={16} />
              {loading ? 'Envoi...' : 'Soumettre la commande'}
            </button>
          </div>
          <p className="text-xs text-slate-400">
            La commande est une demande soumise à validation par la pharmacie.
          </p>
        </div>
      )}
    </div>
  );
}
