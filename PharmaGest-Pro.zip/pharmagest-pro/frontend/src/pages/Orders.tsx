import { useEffect, useState } from 'react';
import { orderApi } from '../services/api';
import { useAuth } from '../contexts/AuthContext';
import { Check, X } from 'lucide-react';

const STATUS_COLORS: Record<string, string> = {
  EN_ATTENTE: 'bg-amber-50 text-amber-700',
  EN_VERIFICATION: 'bg-blue-50 text-blue-700',
  ACCEPTEE: 'bg-emerald-50 text-emerald-700',
  EN_PREPARATION: 'bg-cyan-50 text-cyan-700',
  PRETE: 'bg-purple-50 text-purple-700',
  TERMINEE: 'bg-slate-100 text-slate-600',
  REFUSEE: 'bg-red-50 text-red-700',
  ANNULEE: 'bg-slate-100 text-slate-500',
};

export default function Orders() {
  const { isStaff } = useAuth();
  const [orders, setOrders] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('');

  const load = () => {
    setLoading(true);
    orderApi.list({ status: filter || undefined, limit: 50 })
      .then((r) => setOrders(r.data.data.items))
      .finally(() => setLoading(false));
  };

  useEffect(() => { load(); }, [filter]);

  const updateStatus = async (id: string, status: string, refusalReason?: string) => {
    try {
      await orderApi.updateStatus(id, { status, refusalReason });
      load();
    } catch (err: any) {
      alert(err.response?.data?.message || 'Erreur');
    }
  };

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-2xl font-bold text-slate-900">
          {isStaff ? 'Commandes clients' : 'Mes commandes'}
        </h1>
        <p className="text-slate-500">Suivi et validation des demandes</p>
      </div>

      {isStaff && (
        <div className="flex flex-wrap gap-2">
          {['', 'EN_ATTENTE', 'ACCEPTEE', 'PRETE', 'TERMINEE', 'REFUSEE'].map((s) => (
            <button
              key={s}
              onClick={() => setFilter(s)}
              className={`btn text-xs ${filter === s ? 'btn-primary' : 'btn-secondary'}`}
            >
              {s || 'Toutes'}
            </button>
          ))}
        </div>
      )}

      <div className="card p-0 overflow-hidden">
        {loading ? (
          <div className="flex h-40 items-center justify-center">
            <div className="h-6 w-6 animate-spin rounded-full border-2 border-primary-600 border-t-transparent" />
          </div>
        ) : orders.length === 0 ? (
          <p className="p-8 text-center text-slate-400">Aucune commande</p>
        ) : (
          <table className="w-full text-sm">
            <thead className="bg-slate-50">
              <tr className="text-left text-slate-500">
                <th className="px-4 py-3 font-medium">N°</th>
                {isStaff && <th className="px-4 py-3 font-medium">Client</th>}
                <th className="px-4 py-3 font-medium">Montant</th>
                <th className="px-4 py-3 font-medium">Statut</th>
                <th className="px-4 py-3 font-medium">Date</th>
                {isStaff && <th className="px-4 py-3 font-medium">Actions</th>}
              </tr>
            </thead>
            <tbody>
              {orders.map((o) => (
                <tr key={o.id} className="border-t border-slate-100 hover:bg-slate-50">
                  <td className="px-4 py-2.5 font-medium">{o.orderNumber}</td>
                  {isStaff && (
                    <td className="px-4 py-2.5">
                      {o.client?.firstName} {o.client?.lastName}
                    </td>
                  )}
                  <td className="px-4 py-2.5">{Number(o.totalAmount).toLocaleString()} MGA</td>
                  <td className="px-4 py-2.5">
                    <span className={`badge ${STATUS_COLORS[o.status] || 'bg-slate-100'}`}>
                      {o.status}
                    </span>
                  </td>
                  <td className="px-4 py-2.5 text-slate-500">
                    {new Date(o.createdAt).toLocaleDateString('fr-FR')}
                  </td>
                  {isStaff && (
                    <td className="px-4 py-2.5">
                      <div className="flex gap-1">
                        {o.status === 'EN_ATTENTE' && (
                          <>
                            <button
                              className="btn-success py-1 px-2 text-xs"
                              onClick={() => updateStatus(o.id, 'ACCEPTEE')}
                              title="Accepter"
                            >
                              <Check size={14} />
                            </button>
                            <button
                              className="btn-danger py-1 px-2 text-xs"
                              onClick={() => {
                                const reason = prompt('Motif du refus :');
                                if (reason) updateStatus(o.id, 'REFUSEE', reason);
                              }}
                              title="Refuser"
                            >
                              <X size={14} />
                            </button>
                          </>
                        )}
                        {o.status === 'ACCEPTEE' && (
                          <button
                            className="btn-primary py-1 px-2 text-xs"
                            onClick={() => updateStatus(o.id, 'EN_PREPARATION')}
                          >
                            Préparer
                          </button>
                        )}
                        {o.status === 'EN_PREPARATION' && (
                          <button
                            className="btn-primary py-1 px-2 text-xs"
                            onClick={() => updateStatus(o.id, 'PRETE')}
                          >
                            Prête
                          </button>
                        )}
                      </div>
                    </td>
                  )}
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
