import { useEffect, useState } from 'react';
import { medicineApi } from '../services/api';
import { Search, Plus, ShoppingCart } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export default function Catalog() {
  const [medicines, setMedicines] = useState<any[]>([]);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  const getCart = (): any[] => {
    try {
      return JSON.parse(localStorage.getItem('clientCart') || '[]');
    } catch {
      return [];
    }
  };

  const addToCart = (med: any) => {
    const cart = getCart();
    const existing = cart.find((c: any) => c.medicineId === med.id);
    if (existing) {
      existing.quantity += 1;
    } else {
      cart.push({
        medicineId: med.id,
        name: med.name,
        dosage: med.dosage,
        unitPrice: Number(med.salePrice),
        quantity: 1,
        stock: med.stock,
      });
    }
    localStorage.setItem('clientCart', JSON.stringify(cart));
    alert(`${med.name} ajouté au panier`);
  };

  useEffect(() => {
    setLoading(true);
    medicineApi.list({ search, isActive: true, limit: 50 })
      .then((r) => setMedicines(r.data.data.items))
      .finally(() => setLoading(false));
  }, [search]);

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Catalogue</h1>
          <p className="text-slate-500">Recherchez et commandez vos médicaments</p>
        </div>
        <button className="btn-primary" onClick={() => navigate('/cart')}>
          <ShoppingCart size={18} /> Panier
        </button>
      </div>

      <div className="relative max-w-md">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
        <input
          className="input pl-10"
          placeholder="Nom, principe actif..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
      </div>

      {loading ? (
        <div className="flex h-40 items-center justify-center">
          <div className="h-6 w-6 animate-spin rounded-full border-2 border-primary-600 border-t-transparent" />
        </div>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {medicines.map((m) => (
            <div key={m.id} className="card flex flex-col">
              <div className="flex-1">
                <p className="font-semibold text-slate-900">{m.name}</p>
                {m.dosage && <p className="text-sm text-slate-500">{m.dosage}</p>}
                {m.activeIngredient && (
                  <p className="text-xs text-slate-400 mt-1">{m.activeIngredient}</p>
                )}
                <p className="mt-2 text-lg font-bold text-primary-700">
                  {Number(m.salePrice).toLocaleString()} MGA
                </p>
                <p className={`text-xs mt-1 ${m.stock > 0 ? 'text-emerald-600' : 'text-red-600'}`}>
                  {m.stock > 0 ? `Disponible (${m.stock})` : 'Indisponible'}
                </p>
              </div>
              <button
                className="btn-primary mt-3 w-full"
                disabled={!m.stock || m.stock <= 0}
                onClick={() => addToCart(m)}
              >
                <Plus size={16} /> Ajouter au panier
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
