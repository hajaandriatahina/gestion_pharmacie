import { useEffect, useState } from 'react';
import { medicineApi, categoryApi } from '../services/api';
import { Plus, Search, Edit2, X } from 'lucide-react';

export default function Medicines() {
  const [medicines, setMedicines] = useState<any[]>([]);
  const [categories, setCategories] = useState<any[]>([]);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [form, setForm] = useState({
    code: '', name: '', activeIngredient: '', form: '', dosage: '',
    laboratory: '', purchasePrice: 0, salePrice: 0, minStock: 10,
    requiresPrescription: false, categoryId: '',
  });
  const [error, setError] = useState('');

  const load = () => {
    setLoading(true);
    medicineApi.list({ search, limit: 50 })
      .then((r) => setMedicines(r.data.data.items))
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    load();
    categoryApi.list().then((r) => setCategories(r.data.data));
  }, []);

  useEffect(() => {
    const t = setTimeout(load, 300);
    return () => clearTimeout(t);
  }, [search]);

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    try {
      await medicineApi.create({
        ...form,
        purchasePrice: Number(form.purchasePrice),
        salePrice: Number(form.salePrice),
        minStock: Number(form.minStock),
        categoryId: form.categoryId || undefined,
      });
      setShowModal(false);
      setForm({
        code: '', name: '', activeIngredient: '', form: '', dosage: '',
        laboratory: '', purchasePrice: 0, salePrice: 0, minStock: 10,
        requiresPrescription: false, categoryId: '',
      });
      load();
    } catch (err: any) {
      setError(err.response?.data?.message || 'Erreur');
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Médicaments</h1>
          <p className="text-slate-500">Gestion du catalogue</p>
        </div>
        <button className="btn-primary" onClick={() => setShowModal(true)}>
          <Plus size={18} /> Ajouter
        </button>
      </div>

      <div className="relative max-w-md">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
        <input
          className="input pl-10"
          placeholder="Rechercher..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
      </div>

      <div className="card p-0 overflow-hidden">
        {loading ? (
          <div className="flex h-40 items-center justify-center">
            <div className="h-6 w-6 animate-spin rounded-full border-2 border-primary-600 border-t-transparent" />
          </div>
        ) : medicines.length === 0 ? (
          <p className="p-8 text-center text-slate-400">Aucun médicament trouvé</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-slate-50">
                <tr className="text-left text-slate-500">
                  <th className="px-4 py-3 font-medium">Code</th>
                  <th className="px-4 py-3 font-medium">Nom</th>
                  <th className="px-4 py-3 font-medium">Dosage</th>
                  <th className="px-4 py-3 font-medium">Prix vente</th>
                  <th className="px-4 py-3 font-medium">Stock</th>
                  <th className="px-4 py-3 font-medium">Statut</th>
                </tr>
              </thead>
              <tbody>
                {medicines.map((m) => (
                  <tr key={m.id} className="border-t border-slate-100 hover:bg-slate-50">
                    <td className="px-4 py-2.5 font-mono text-xs">{m.code}</td>
                    <td className="px-4 py-2.5">
                      <p className="font-medium">{m.name}</p>
                      {m.activeIngredient && (
                        <p className="text-xs text-slate-500">{m.activeIngredient}</p>
                      )}
                    </td>
                    <td className="px-4 py-2.5 text-slate-600">{m.dosage || '—'}</td>
                    <td className="px-4 py-2.5 font-medium">{Number(m.salePrice).toLocaleString()} MGA</td>
                    <td className="px-4 py-2.5">
                      <span className={m.stock <= m.minStock ? 'text-red-600 font-medium' : ''}>
                        {m.stock ?? 0}
                      </span>
                    </td>
                    <td className="px-4 py-2.5">
                      <span className={`badge ${m.isActive ? 'bg-emerald-50 text-emerald-700' : 'bg-slate-100 text-slate-500'}`}>
                        {m.isActive ? 'Actif' : 'Inactif'}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Modal */}
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4">
          <div className="w-full max-w-lg rounded-xl bg-white p-6 shadow-xl max-h-[90vh] overflow-y-auto">
            <div className="mb-4 flex items-center justify-between">
              <h2 className="text-lg font-semibold">Nouveau médicament</h2>
              <button onClick={() => setShowModal(false)}><X size={20} /></button>
            </div>
            {error && <div className="mb-3 rounded-lg bg-red-50 px-3 py-2 text-sm text-red-700">{error}</div>}
            <form onSubmit={handleCreate} className="space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-medium text-slate-600">Code *</label>
                  <input className="input" required value={form.code} onChange={(e) => setForm({ ...form, code: e.target.value })} />
                </div>
                <div>
                  <label className="text-xs font-medium text-slate-600">Nom *</label>
                  <input className="input" required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-medium text-slate-600">Principe actif</label>
                  <input className="input" value={form.activeIngredient} onChange={(e) => setForm({ ...form, activeIngredient: e.target.value })} />
                </div>
                <div>
                  <label className="text-xs font-medium text-slate-600">Dosage</label>
                  <input className="input" value={form.dosage} onChange={(e) => setForm({ ...form, dosage: e.target.value })} />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-medium text-slate-600">Forme</label>
                  <input className="input" value={form.form} onChange={(e) => setForm({ ...form, form: e.target.value })} />
                </div>
                <div>
                  <label className="text-xs font-medium text-slate-600">Laboratoire</label>
                  <input className="input" value={form.laboratory} onChange={(e) => setForm({ ...form, laboratory: e.target.value })} />
                </div>
              </div>
              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="text-xs font-medium text-slate-600">Prix d'achat *</label>
                  <input type="number" className="input" required min={0} value={form.purchasePrice} onChange={(e) => setForm({ ...form, purchasePrice: +e.target.value })} />
                </div>
                <div>
                  <label className="text-xs font-medium text-slate-600">Prix de vente *</label>
                  <input type="number" className="input" required min={0} value={form.salePrice} onChange={(e) => setForm({ ...form, salePrice: +e.target.value })} />
                </div>
                <div>
                  <label className="text-xs font-medium text-slate-600">Seuil min</label>
                  <input type="number" className="input" min={0} value={form.minStock} onChange={(e) => setForm({ ...form, minStock: +e.target.value })} />
                </div>
              </div>
              <div>
                <label className="text-xs font-medium text-slate-600">Catégorie</label>
                <select className="input" value={form.categoryId} onChange={(e) => setForm({ ...form, categoryId: e.target.value })}>
                  <option value="">— Aucune —</option>
                  {categories.map((c) => (
                    <option key={c.id} value={c.id}>{c.name}</option>
                  ))}
                </select>
              </div>
              <label className="flex items-center gap-2 text-sm">
                <input type="checkbox" checked={form.requiresPrescription} onChange={(e) => setForm({ ...form, requiresPrescription: e.target.checked })} />
                Nécessite une ordonnance
              </label>
              <div className="flex justify-end gap-2 pt-2">
                <button type="button" className="btn-secondary" onClick={() => setShowModal(false)}>Annuler</button>
                <button type="submit" className="btn-primary">Créer</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
