import { useState, useRef, useEffect } from 'react';
import { medicineApi, saleApi } from '../services/api';
import { Search, Plus, Minus, Trash2, CreditCard, Printer } from 'lucide-react';

interface CartItem {
  medicineId: string;
  name: string;
  dosage?: string;
  unitPrice: number;
  quantity: number;
  stock: number;
  requiresPrescription: boolean;
}

interface SearchResult {
  id: string;
  code: string;
  name: string;
  dosage?: string;
  salePrice: number;
  stock: number;
  requiresPrescription: boolean;
}

export default function POS() {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<SearchResult[]>([]);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [paymentMethod, setPaymentMethod] = useState('ESPECES');
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [lastSale, setLastSale] = useState<any>(null);
  const searchRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    searchRef.current?.focus();
  }, []);

  useEffect(() => {
    if (query.length < 1) {
      setResults([]);
      return;
    }
    const t = setTimeout(() => {
      medicineApi.searchPOS(query)
        .then((r) => setResults(r.data.data))
        .catch(() => setResults([]));
    }, 250);
    return () => clearTimeout(t);
  }, [query]);

  const addToCart = (item: SearchResult) => {
    if (item.stock <= 0) {
      setMessage({ type: 'error', text: 'Stock insuffisant' });
      return;
    }
    setCart((prev) => {
      const existing = prev.find((c) => c.medicineId === item.id);
      if (existing) {
        if (existing.quantity >= item.stock) {
          setMessage({ type: 'error', text: 'Quantité max atteinte' });
          return prev;
        }
        return prev.map((c) =>
          c.medicineId === item.id ? { ...c, quantity: c.quantity + 1 } : c
        );
      }
      return [
        ...prev,
        {
          medicineId: item.id,
          name: item.name,
          dosage: item.dosage,
          unitPrice: item.salePrice,
          quantity: 1,
          stock: item.stock,
          requiresPrescription: item.requiresPrescription,
        },
      ];
    });
    setQuery('');
    setResults([]);
    searchRef.current?.focus();
  };

  const updateQty = (id: string, delta: number) => {
    setCart((prev) =>
      prev
        .map((c) => {
          if (c.medicineId !== id) return c;
          const newQty = c.quantity + delta;
          if (newQty > c.stock) return c;
          return { ...c, quantity: newQty };
        })
        .filter((c) => c.quantity > 0)
    );
  };

  const removeItem = (id: string) => {
    setCart((prev) => prev.filter((c) => c.medicineId !== id));
  };

  const total = cart.reduce((s, c) => s + c.unitPrice * c.quantity, 0);
  const hasPrescription = cart.some((c) => c.requiresPrescription);

  const handleValidate = async () => {
    if (!cart.length) return;
    setLoading(true);
    setMessage(null);
    try {
      const res = await saleApi.create({
        items: cart.map((c) => ({
          medicineId: c.medicineId,
          quantity: c.quantity,
          unitPrice: c.unitPrice,
        })),
        paymentMethod,
      });
      setLastSale(res.data.data);
      setCart([]);
      setMessage({ type: 'success', text: `Vente ${res.data.data.saleNumber} enregistrée !` });
    } catch (err: any) {
      setMessage({
        type: 'error',
        text: err.response?.data?.message || 'Erreur lors de la validation',
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-2xl font-bold text-slate-900">Point de vente (POS)</h1>
        <p className="text-slate-500">Recherchez un médicament et validez la vente</p>
      </div>

      {message && (
        <div className={`rounded-lg px-4 py-3 text-sm ${message.type === 'success' ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' : 'bg-red-50 text-red-700 border border-red-200'}`}>
          {message.text}
        </div>
      )}

      <div className="grid gap-6 lg:grid-cols-5">
        {/* Recherche */}
        <div className="lg:col-span-3 space-y-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
            <input
              ref={searchRef}
              type="text"
              className="input pl-10 text-lg py-3"
              placeholder="Nom, principe actif ou code-barres..."
              value={query}
              onChange={(e) => setQuery(e.target.value)}
            />
          </div>

          {results.length > 0 && (
            <div className="card p-0 overflow-hidden">
              <table className="w-full text-sm">
                <thead className="bg-slate-50">
                  <tr className="text-left text-slate-500">
                    <th className="px-4 py-2 font-medium">Médicament</th>
                    <th className="px-4 py-2 font-medium">Prix</th>
                    <th className="px-4 py-2 font-medium">Stock</th>
                    <th className="px-4 py-2"></th>
                  </tr>
                </thead>
                <tbody>
                  {results.map((r) => (
                    <tr key={r.id} className="border-t border-slate-100 hover:bg-slate-50">
                      <td className="px-4 py-2.5">
                        <p className="font-medium">{r.name}</p>
                        <p className="text-xs text-slate-500">{r.code} {r.dosage && `• ${r.dosage}`}</p>
                        {r.requiresPrescription && (
                          <span className="badge bg-amber-50 text-amber-700 mt-0.5">Ordonnance</span>
                        )}
                      </td>
                      <td className="px-4 py-2.5 font-medium">{r.salePrice.toLocaleString()} MGA</td>
                      <td className="px-4 py-2.5">
                        <span className={r.stock <= 0 ? 'text-red-600' : 'text-slate-700'}>{r.stock}</span>
                      </td>
                      <td className="px-4 py-2.5">
                        <button
                          className="btn-primary py-1 px-2 text-xs"
                          onClick={() => addToCart(r)}
                          disabled={r.stock <= 0}
                        >
                          <Plus size={14} /> Ajouter
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {lastSale && (
            <div className="card border-emerald-200 bg-emerald-50">
              <p className="font-medium text-emerald-800">Dernière vente : {lastSale.saleNumber}</p>
              <p className="text-sm text-emerald-700">Total : {lastSale.totalAmount?.toLocaleString()} MGA</p>
              {lastSale.invoice && (
                <p className="text-xs text-emerald-600 mt-1">Facture {lastSale.invoice.invoiceNumber} générée</p>
              )}
            </div>
          )}
        </div>

        {/* Panier */}
        <div className="lg:col-span-2">
          <div className="card sticky top-4">
            <h3 className="mb-4 font-semibold text-slate-800">Panier de vente</h3>

            {cart.length === 0 ? (
              <p className="text-sm text-slate-400 text-center py-8">Panier vide</p>
            ) : (
              <ul className="space-y-3 mb-4 max-h-64 overflow-y-auto">
                {cart.map((item) => (
                  <li key={item.medicineId} className="flex items-start gap-2 border-b border-slate-100 pb-3">
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium truncate">{item.name}</p>
                      <p className="text-xs text-slate-500">{item.unitPrice.toLocaleString()} MGA</p>
                    </div>
                    <div className="flex items-center gap-1">
                      <button className="rounded p-1 hover:bg-slate-100" onClick={() => updateQty(item.medicineId, -1)}>
                        <Minus size={14} />
                      </button>
                      <span className="w-6 text-center text-sm font-medium">{item.quantity}</span>
                      <button className="rounded p-1 hover:bg-slate-100" onClick={() => updateQty(item.medicineId, 1)}>
                        <Plus size={14} />
                      </button>
                      <button className="rounded p-1 text-red-500 hover:bg-red-50 ml-1" onClick={() => removeItem(item.medicineId)}>
                        <Trash2 size={14} />
                      </button>
                    </div>
                  </li>
                ))}
              </ul>
            )}

            {hasPrescription && (
              <div className="mb-3 rounded-lg bg-amber-50 border border-amber-200 px-3 py-2 text-xs text-amber-700">
                ⚠ Certains produits nécessitent une ordonnance. Vérifiez avant de délivrer.
              </div>
            )}

            <div className="border-t border-slate-200 pt-3 space-y-3">
              <div className="flex justify-between text-lg font-bold">
                <span>Total</span>
                <span>{total.toLocaleString()} MGA</span>
              </div>

              <div>
                <label className="mb-1 block text-xs font-medium text-slate-600">Mode de paiement</label>
                <select
                  className="input"
                  value={paymentMethod}
                  onChange={(e) => setPaymentMethod(e.target.value)}
                >
                  <option value="ESPECES">Espèces</option>
                  <option value="CARTE">Carte bancaire</option>
                  <option value="MOBILE_MONEY">Mobile Money</option>
                  <option value="CHEQUE">Chèque</option>
                </select>
              </div>

              <button
                className="btn-success w-full py-3"
                disabled={!cart.length || loading}
                onClick={handleValidate}
              >
                <CreditCard size={18} />
                {loading ? 'Validation...' : 'Valider la vente'}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
