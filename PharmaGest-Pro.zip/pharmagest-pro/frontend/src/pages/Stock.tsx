import { useEffect, useState } from 'react';
import { stockApi, medicineApi } from '../services/api';
import { AlertTriangle, Package, Plus, X } from 'lucide-react';

export default function Stock() {
  const [lowStock, setLowStock] = useState<any[]>([]);
  const [expiring, setExpiring] = useState<any[]>([]);
  const [tab, setTab] = useState<'low' | 'expiring' | 'receive'>('low');
  const [medicines, setMedicines] = useState<any[]>([]);
  const [form, setForm] = useState({
    medicineId: '', batchNumber: '', quantity: 50, expiryDate: '', purchasePrice: 0,
  });
  const [msg, setMsg] = useState('');
  const [error, setError] = useState('');

  useEffect(() => {
    stockApi.low().then((r) => setLowStock(r.data.data));
    stockApi.expiring(90).then((r) => setExpiring(r.data.data));
    medicineApi.list({ limit: 100 }).then((r) => setMedicines(r.data.data.items));
  }, []);

  const handleReceive = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setMsg('');
    try {
      await stockApi.receive({
        ...form,
        quantity: Number(form.quantity),
        purchasePrice: Number(form.purchasePrice),
      });
      setMsg('Entrée de stock enregistrée');
      setForm({ medicineId: '', batchNumber: '', quantity: 50, expiryDate: '', purchasePrice: 0 });
      stockApi.low().then((r) => setLowStock(r.data.data));
    } catch (err: any) {
      setError(err.response?.data?.message || 'Erreur');
    }
  };

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-2xl font-bold text-slate-900">Gestion du stock</h1>
        <p className="text-slate-500">Alertes, péremptions et entrées</p>
      </div>

      <div className="flex gap-2">
        {[
          { key: 'low', label: 'Stock faible', icon: AlertTriangle },
          { key: 'expiring', label: 'Péremption', icon: Package },
          { key: 'receive', label: 'Entrée stock', icon: Plus },
        ].map((t) => (
          <button
            key={t.key}
            onClick={() => setTab(t.key as any)}
            className={`btn ${tab === t.key ? 'btn-primary' : 'btn-secondary'}`}
          >
            <t.icon size={16} /> {t.label}
          </button>
        ))}
      </div>

      {tab === 'low' && (
        <div className="card p-0 overflow-hidden">
          {lowStock.length === 0 ? (
            <p className="p-8 text-center text-slate-400">Aucun stock faible</p>
          ) : (
            <table className="w-full text-sm">
              <thead className="bg-slate-50">
                <tr className="text-left text-slate-500">
                  <th className="px-4 py-3 font-medium">Code</th>
                  <th className="px-4 py-3 font-medium">Médicament</th>
                  <th className="px-4 py-3 font-medium">Stock</th>
                  <th className="px-4 py-3 font-medium">Seuil</th>
                  <th className="px-4 py-3 font-medium">État</th>
                </tr>
              </thead>
              <tbody>
                {lowStock.map((m) => (
                  <tr key={m.id} className="border-t border-slate-100">
                    <td className="px-4 py-2.5 font-mono text-xs">{m.code}</td>
                    <td className="px-4 py-2.5 font-medium">{m.name}</td>
                    <td className="px-4 py-2.5 text-red-600 font-medium">{m.stock}</td>
                    <td className="px-4 py-2.5">{m.minStock}</td>
                    <td className="px-4 py-2.5">
                      <span className={`badge ${m.isOut ? 'bg-red-50 text-red-700' : 'bg-amber-50 text-amber-700'}`}>
                        {m.isOut ? 'Rupture' : 'Faible'}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      )}

      {tab === 'expiring' && (
        <div className="card p-0 overflow-hidden">
          {expiring.length === 0 ? (
            <p className="p-8 text-center text-slate-400">Aucun lot proche de la péremption</p>
          ) : (
            <table className="w-full text-sm">
              <thead className="bg-slate-50">
                <tr className="text-left text-slate-500">
                  <th className="px-4 py-3 font-medium">Lot</th>
                  <th className="px-4 py-3 font-medium">Médicament</th>
                  <th className="px-4 py-3 font-medium">Quantité</th>
                  <th className="px-4 py-3 font-medium">Expiration</th>
                </tr>
              </thead>
              <tbody>
                {expiring.map((b) => (
                  <tr key={b.id} className="border-t border-slate-100">
                    <td className="px-4 py-2.5 font-mono text-xs">{b.batchNumber}</td>
                    <td className="px-4 py-2.5 font-medium">{b.medicine?.name}</td>
                    <td className="px-4 py-2.5">{b.quantity}</td>
                    <td className="px-4 py-2.5 text-amber-600">
                      {new Date(b.expiryDate).toLocaleDateString('fr-FR')}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      )}

      {tab === 'receive' && (
        <div className="card max-w-lg">
          <h3 className="mb-4 font-semibold">Réception de stock</h3>
          {msg && <div className="mb-3 rounded-lg bg-emerald-50 px-3 py-2 text-sm text-emerald-700">{msg}</div>}
          {error && <div className="mb-3 rounded-lg bg-red-50 px-3 py-2 text-sm text-red-700">{error}</div>}
          <form onSubmit={handleReceive} className="space-y-3">
            <div>
              <label className="text-xs font-medium text-slate-600">Médicament *</label>
              <select className="input" required value={form.medicineId} onChange={(e) => setForm({ ...form, medicineId: e.target.value })}>
                <option value="">— Sélectionner —</option>
                {medicines.map((m) => (
                  <option key={m.id} value={m.id}>{m.name} ({m.code})</option>
                ))}
              </select>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-medium text-slate-600">N° de lot *</label>
                <input className="input" required value={form.batchNumber} onChange={(e) => setForm({ ...form, batchNumber: e.target.value })} />
              </div>
              <div>
                <label className="text-xs font-medium text-slate-600">Quantité *</label>
                <input type="number" className="input" required min={1} value={form.quantity} onChange={(e) => setForm({ ...form, quantity: +e.target.value })} />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-medium text-slate-600">Date d'expiration *</label>
                <input type="date" className="input" required value={form.expiryDate} onChange={(e) => setForm({ ...form, expiryDate: e.target.value })} />
              </div>
              <div>
                <label className="text-xs font-medium text-slate-600">Prix d'achat *</label>
                <input type="number" className="input" required min={0} value={form.purchasePrice} onChange={(e) => setForm({ ...form, purchasePrice: +e.target.value })} />
              </div>
            </div>
            <button type="submit" className="btn-primary">Enregistrer l'entrée</button>
          </form>
        </div>
      )}
    </div>
  );
}
