import { useEffect, useState } from 'react';
import { notificationApi } from '../services/api';
import { Bell } from 'lucide-react';

export default function Notifications() {
  const [items, setItems] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  const load = () => {
    setLoading(true);
    notificationApi.list()
      .then((r) => setItems(r.data.data))
      .finally(() => setLoading(false));
  };

  useEffect(() => { load(); }, []);

  const markAll = async () => {
    await notificationApi.markAllRead();
    load();
  };

  const markOne = async (id: string) => {
    await notificationApi.markRead(id);
    load();
  };

  return (
    <div className="space-y-4 max-w-2xl">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Notifications</h1>
          <p className="text-slate-500">Alertes et messages</p>
        </div>
        <button className="btn-secondary text-sm" onClick={markAll}>
          Tout marquer comme lu
        </button>
      </div>

      {loading ? (
        <div className="flex h-40 items-center justify-center">
          <div className="h-6 w-6 animate-spin rounded-full border-2 border-primary-600 border-t-transparent" />
        </div>
      ) : items.length === 0 ? (
        <div className="card text-center py-12 text-slate-400">
          <Bell size={32} className="mx-auto mb-2 opacity-40" />
          <p>Aucune notification</p>
        </div>
      ) : (
        <div className="space-y-2">
          {items.map((n) => (
            <div
              key={n.id}
              className={`card cursor-pointer transition-colors ${!n.isRead ? 'border-primary-200 bg-primary-50/50' : ''}`}
              onClick={() => !n.isRead && markOne(n.id)}
            >
              <div className="flex items-start justify-between gap-2">
                <div>
                  <p className="font-medium text-slate-800">{n.title}</p>
                  <p className="text-sm text-slate-600 mt-0.5">{n.message}</p>
                  <p className="text-xs text-slate-400 mt-1">
                    {new Date(n.createdAt).toLocaleString('fr-FR')}
                  </p>
                </div>
                {!n.isRead && (
                  <span className="h-2.5 w-2.5 rounded-full bg-primary-600 flex-shrink-0 mt-1.5" />
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
