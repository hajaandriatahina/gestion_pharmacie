import { useEffect, useState } from 'react';
import { saleApi } from '../services/api';

export default function Sales() {
  const [sales, setSales] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    saleApi.list({ limit: 50 })
      .then((r) => setSales(r.data.data.items))
      .finally(() => setLoading(false));
  }, []);

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-2xl font-bold text-slate-900">Historique des ventes</h1>
        <p className="text-slate-500">Toutes les ventes enregistrées</p>
      </div>

      <div className="card p-0 overflow-hidden">
        {loading ? (
          <div className="flex h-40 items-center justify-center">
            <div className="h-6 w-6 animate-spin rounded-full border-2 border-primary-600 border-t-transparent" />
          </div>
        ) : sales.length === 0 ? (
          <p className="p-8 text-center text-slate-400">Aucune vente</p>
        ) : (
          <table className="w-full text-sm">
            <thead className="bg-slate-50">
              <tr className="text-left text-slate-500">
                <th className="px-4 py-3 font-medium">N° Vente</th>
                <th className="px-4 py-3 font-medium">Montant</th>
                <th className="px-4 py-3 font-medium">Paiement</th>
                <th className="px-4 py-3 font-medium">Vendeur</th>
                <th className="px-4 py-3 font-medium">Date</th>
                <th className="px-4 py-3 font-medium">Facture</th>
              </tr>
            </thead>
            <tbody>
              {sales.map((s) => (
                <tr key={s.id} className="border-t border-slate-100 hover:bg-slate-50">
                  <td className="px-4 py-2.5 font-medium">{s.saleNumber}</td>
                  <td className="px-4 py-2.5 font-medium">{Number(s.totalAmount).toLocaleString()} MGA</td>
                  <td className="px-4 py-2.5">
                    <span className="badge bg-slate-100 text-slate-600">{s.paymentMethod}</span>
                  </td>
                  <td className="px-4 py-2.5 text-slate-600">
                    {s.seller?.firstName} {s.seller?.lastName}
                  </td>
                  <td className="px-4 py-2.5 text-slate-500">
                    {new Date(s.createdAt).toLocaleString('fr-FR')}
                  </td>
                  <td className="px-4 py-2.5 text-xs text-primary-600">
                    {s.invoice?.invoiceNumber || '—'}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
