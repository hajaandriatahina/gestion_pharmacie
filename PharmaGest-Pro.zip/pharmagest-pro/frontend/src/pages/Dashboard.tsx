import { useEffect, useState } from 'react';
import { dashboardApi } from '../services/api';
import { Package, AlertTriangle, ShoppingCart, TrendingUp, ClipboardList, Pill } from 'lucide-react';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
} from 'recharts';

interface Stats {
  activeMedicines: number;
  stockValue: number;
  lowStockCount: number;
  expiringCount: number;
  pendingOrders: number;
  todaySalesCount: number;
  todayRevenue: number;
  salesChart: { date: string; amount: number }[];
  topMedicines: { name: string; quantity: number }[];
  recentSales: any[];
  recentOrders: any[];
}

export default function Dashboard() {
  const [stats, setStats] = useState<Stats | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    dashboardApi.stats()
      .then((r) => setStats(r.data.data))
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  if (loading) {
    return (
      <div className="flex h-64 items-center justify-center">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary-600 border-t-transparent" />
      </div>
    );
  }

  if (!stats) return <p className="text-slate-500">Impossible de charger les statistiques.</p>;

  const cards = [
    { label: 'Médicaments actifs', value: stats.activeMedicines, icon: Pill, color: 'bg-blue-50 text-blue-600' },
    { label: 'Valeur du stock', value: `${stats.stockValue.toLocaleString()} MGA`, icon: Package, color: 'bg-emerald-50 text-emerald-600' },
    { label: 'Stock faible', value: stats.lowStockCount, icon: AlertTriangle, color: 'bg-amber-50 text-amber-600' },
    { label: 'Péremption proche', value: stats.expiringCount, icon: AlertTriangle, color: 'bg-orange-50 text-orange-600' },
    { label: 'Commandes en attente', value: stats.pendingOrders, icon: ClipboardList, color: 'bg-purple-50 text-purple-600' },
    { label: 'Ventes du jour', value: stats.todaySalesCount, icon: ShoppingCart, color: 'bg-cyan-50 text-cyan-600' },
    { label: 'CA du jour', value: `${stats.todayRevenue.toLocaleString()} MGA`, icon: TrendingUp, color: 'bg-green-50 text-green-600' },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-slate-900">Tableau de bord</h1>
        <p className="text-slate-500">Vue d'ensemble de la pharmacie</p>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
        {cards.map((c) => (
          <div key={c.label} className="card flex items-start gap-4">
            <div className={`rounded-lg p-2.5 ${c.color}`}>
              <c.icon size={20} />
            </div>
            <div>
              <p className="text-sm text-slate-500">{c.label}</p>
              <p className="text-xl font-bold text-slate-900">{c.value}</p>
            </div>
          </div>
        ))}
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <div className="card">
          <h3 className="mb-4 font-semibold text-slate-800">Ventes des 7 derniers jours</h3>
          <ResponsiveContainer width="100%" height={250}>
            <BarChart data={stats.salesChart}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
              <XAxis dataKey="date" tick={{ fontSize: 11 }} tickFormatter={(v) => v.slice(5)} />
              <YAxis tick={{ fontSize: 11 }} />
              <Tooltip formatter={(v: number) => [`${v.toLocaleString()} MGA`, 'CA']} />
              <Bar dataKey="amount" fill="#2563eb" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="card">
          <h3 className="mb-4 font-semibold text-slate-800">Médicaments les plus vendus</h3>
          {stats.topMedicines.length === 0 ? (
            <p className="text-sm text-slate-500">Aucune vente enregistrée</p>
          ) : (
            <ul className="space-y-3">
              {stats.topMedicines.map((m, i) => (
                <li key={i} className="flex items-center justify-between">
                  <span className="text-sm text-slate-700">{m.name}</span>
                  <span className="badge bg-primary-50 text-primary-700">{m.quantity} unités</span>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <div className="card">
          <h3 className="mb-4 font-semibold text-slate-800">Dernières ventes</h3>
          {stats.recentSales.length === 0 ? (
            <p className="text-sm text-slate-500">Aucune vente</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b text-left text-slate-500">
                    <th className="pb-2 font-medium">N°</th>
                    <th className="pb-2 font-medium">Montant</th>
                    <th className="pb-2 font-medium">Vendeur</th>
                  </tr>
                </thead>
                <tbody>
                  {stats.recentSales.map((s) => (
                    <tr key={s.id} className="border-b border-slate-100">
                      <td className="py-2 font-medium">{s.saleNumber}</td>
                      <td className="py-2">{s.totalAmount.toLocaleString()} MGA</td>
                      <td className="py-2 text-slate-500">{s.seller}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        <div className="card">
          <h3 className="mb-4 font-semibold text-slate-800">Dernières commandes</h3>
          {stats.recentOrders.length === 0 ? (
            <p className="text-sm text-slate-500">Aucune commande</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b text-left text-slate-500">
                    <th className="pb-2 font-medium">N°</th>
                    <th className="pb-2 font-medium">Client</th>
                    <th className="pb-2 font-medium">Statut</th>
                  </tr>
                </thead>
                <tbody>
                  {stats.recentOrders.map((o) => (
                    <tr key={o.id} className="border-b border-slate-100">
                      <td className="py-2 font-medium">{o.orderNumber}</td>
                      <td className="py-2">{o.client}</td>
                      <td className="py-2">
                        <span className="badge bg-slate-100 text-slate-700">{o.status}</span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
