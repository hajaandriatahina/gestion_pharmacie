import axios from 'axios';

const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL || 'http://localhost:5000/api',
  headers: { 'Content-Type': 'application/json' },
});

api.interceptors.request.use((config) => {
  const token = localStorage.getItem('token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

api.interceptors.response.use(
  (res) => res,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('token');
      localStorage.removeItem('user');
      if (!window.location.pathname.includes('/login')) {
        window.location.href = '/login';
      }
    }
    return Promise.reject(error);
  }
);

export default api;

// Auth
export const authApi = {
  login: (email: string, password: string) =>
    api.post('/auth/login', { email, password }),
  register: (data: any) => api.post('/auth/register', data),
  me: () => api.get('/auth/me'),
};

// Medicines
export const medicineApi = {
  list: (params?: any) => api.get('/medicines', { params }),
  get: (id: string) => api.get(`/medicines/${id}`),
  create: (data: any) => api.post('/medicines', data),
  update: (id: string, data: any) => api.put(`/medicines/${id}`, data),
  searchPOS: (q: string) => api.get('/medicines/search', { params: { q } }),
};

// Stock
export const stockApi = {
  receive: (data: any) => api.post('/stock/receive', data),
  low: () => api.get('/stock/low'),
  expiring: (days?: number) => api.get('/stock/expiring', { params: { days } }),
  expired: () => api.get('/stock/expired'),
  movements: (params?: any) => api.get('/stock/movements', { params }),
};

// Sales
export const saleApi = {
  create: (data: any) => api.post('/sales', data),
  list: (params?: any) => api.get('/sales', { params }),
  get: (id: string) => api.get(`/sales/${id}`),
};

// Orders
export const orderApi = {
  create: (data: any) => api.post('/orders', data),
  list: (params?: any) => api.get('/orders', { params }),
  get: (id: string) => api.get(`/orders/${id}`),
  updateStatus: (id: string, data: any) => api.patch(`/orders/${id}/status`, data),
};

// Dashboard
export const dashboardApi = {
  stats: () => api.get('/dashboard/stats'),
};

// Notifications
export const notificationApi = {
  list: (unread?: boolean) => api.get('/notifications', { params: { unread } }),
  unreadCount: () => api.get('/notifications/unread-count'),
  markRead: (id: string) => api.patch(`/notifications/${id}/read`),
  markAllRead: () => api.patch('/notifications/read-all'),
};

// Categories
export const categoryApi = {
  list: () => api.get('/categories'),
  create: (data: any) => api.post('/categories', data),
};

// Users
export const userApi = {
  list: () => api.get('/users'),
  create: (data: any) => api.post('/users', data),
  toggleActive: (id: string) => api.patch(`/users/${id}/toggle-active`),
};

// Invoices
export const invoiceApi = {
  download: (id: string) =>
    api.get(`/invoices/${id}/download`, { responseType: 'blob' }),
};
